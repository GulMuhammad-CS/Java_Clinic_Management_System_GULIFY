package com.example.demo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

import java.sql.*;

import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

import static com.example.demo.changepage.changePage;

public class adminRegistration {
    String url = "jdbc:sqlite:Clinic_database.db";
    public void showErrorAlert(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    public void showSuccessAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText("Administrator Registration successful!");
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private TextField namefield;
    @FXML
    private TextField emailfield;
    @FXML
    private PasswordField passwordfield;
    @FXML
    private PasswordField confirmpasswordfield;
    @FXML
    private void handleSubmit(ActionEvent event) {
        String name = namefield.getText();
        String email = emailfield.getText();
        String password = passwordfield.getText();
        String confirmpassword = confirmpasswordfield.getText();
        int count_checks = 0;
        if (name.isEmpty() || email.isEmpty() || password.isEmpty() || confirmpassword.isEmpty()) {
            showErrorAlert("Please fill all the fields");
            return;
        }
        else{
            count_checks++;
        }
        if(password.length()<7){
            showErrorAlert("Password must be at least 7 characters");
            return;
        }
        else{
            count_checks++;
        }
        if(name.matches(".*\\d.*")){
            showErrorAlert("Please enter a valid name. It should not have numbers");
            return;
        }
        if(!password.equals(confirmpassword)){
            showErrorAlert("Passwords do not match");
            return;
        }
        else{
            count_checks++;
        }
        if(!email.contains("@clincare.com")){
            showErrorAlert("Please enter a valid email address");
            return;
        }
        else{
            count_checks++;
        }
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT AdminEmail FROM Admins")) {

            while(rs.next()) {
                if(email.equals(rs.getString("AdminEmail"))) {
                    showErrorAlert("Email already exists");
                    return;
                }
                else{
                    count_checks++;
                }
            }

        } catch (Exception e) {
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;}

        try(Connection conn = DriverManager.getConnection(url)){
            String sql = "INSERT INTO Admins (AdminName, AdminEmail, AdminPassword,  AccessLevel) " +
                    "VALUES (?, ?, ?, ?)";

            PreparedStatement pstmt = conn.prepareStatement(sql);


            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, password);
            pstmt.setInt(4, 2);
            pstmt.executeUpdate();
            showSuccessAlert("Administrator successfully Registered!");
            namefield.clear();
            emailfield.clear();
            passwordfield.clear();
            confirmpasswordfield.clear();
        }
        catch(Exception e){
            e.printStackTrace();
            showErrorAlert("Database error: " + e.getMessage());
        }
        boolean superuserpresent=false;
        String superuserpresentquery = "SELECT * FROM Admins WHERE AccessLevel=1";
        try(Connection conn = DriverManager.getConnection(url);
        Statement stmt=conn.createStatement();
        ResultSet rs = stmt.executeQuery(superuserpresentquery)) {
            if(rs.next()){
                superuserpresent=true;
            }
        }
        catch(Exception e){
            e.printStackTrace();
            showErrorAlert("Database error: " + e.getMessage());
            return;
        }
        if(superuserpresent){
            try(Connection conn=DriverManager.getConnection(url);){
                String removesuperuserquery="DELETE FROM Admins WHERE AccessLevel=1";
                Statement stmt = conn.createStatement();
                stmt.executeUpdate(removesuperuserquery);
            }
            catch(Exception e){
                e.printStackTrace();
                showErrorAlert("Database error: " + e.getMessage());
            }
            changePage(event, "adminLoginpage.fxml", false);

        }
        if(!superuserpresent){
            changePage(event, "AdminProfilePage.fxml", true);
        }

    }
    @FXML
    private void cancel(ActionEvent event) {
        changePage(event, "AdminProfilePage.fxml", true);
    }
    @FXML
    private void gotoprofile(ActionEvent event) {
        changePage(event, "AdminProfilePage.fxml", true);

    }
}






