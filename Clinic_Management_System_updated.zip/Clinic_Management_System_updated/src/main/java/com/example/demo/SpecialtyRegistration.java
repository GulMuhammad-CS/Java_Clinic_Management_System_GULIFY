package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.*;

import static com.example.demo.changepage.changePage;

public class SpecialtyRegistration {
    String url = "jdbc:sqlite:Clinic_database.db";
    public void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    public void showSuccessAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText("Specialty Registration successful!");
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private TextField specialtynamefield;
    @FXML
    private void handleSubmit(ActionEvent event) {
        String specialtyname = specialtynamefield.getText();
        specialtyname=specialtyname.toLowerCase();
        if(specialtyname.isEmpty()){
            showErrorAlert("Please enter a valid Specialty name");
            return;
        }
        //basic checks for specialty name, as well as names for the patients, doctors, and admins includes a check for
        //any numbers in the entered name
        if(specialtyname.matches(".*\\d.*")){
            showErrorAlert("Please enter a valid Specialty name. It should not have numbers");
            return;
        }
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Specialties")) {

            while(rs.next()) {
                if(specialtyname.equals(rs.getString("Specialty"))) {
                    showErrorAlert("Specialty already exists");
                    return;
                }
            }
        } catch (Exception e) {
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;
        }
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();) {
//            String addDetails = "INSERT INTO Specialties (Specialty) VALUES('" + specialtyname +"')";
//            stmt.execute(addDetails);
            String sql = "INSERT INTO Specialties (Specialty) VALUES (?)";

            // Create a PreparedStatement
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // Set each parameter with the appropriate data type
            pstmt.setString(1, specialtyname);
            pstmt.executeUpdate();
            specialtynamefield.clear();
            showSuccessAlert("Specialty: "+specialtyname+" has successfully been registered!");
        } catch (Exception e) {
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;
        }
        changePage(event, "AdminProfilePage.fxml", true);
    }
    @FXML
    private Button cancelbutton;
    @FXML
    private void cancel(ActionEvent event) {
        changePage(event, "AdminProfilePage.fxml", true);
    }
}
