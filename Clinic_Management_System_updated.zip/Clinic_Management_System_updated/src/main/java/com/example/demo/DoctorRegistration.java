package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.*;

import static com.example.demo.changepage.changePage;

public class DoctorRegistration {
    String url = "jdbc:sqlite:Clinic_database.db";
    public void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    public void showSuccessAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText("Doctor Registration successful!");
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private TextField emailfield;
    @FXML
    private TextField passwordfield;
    @FXML
    private TextField namefield;
    @FXML
    private TextField confirmpasswordfield;
    @FXML
    private ChoiceBox<String> specialtyfield;
    int specialtyID=-1;
    @FXML
    public void initialize(){
        //initializes options for choicebox based on records in specialties table
        try(Connection conn = DriverManager.getConnection(url);
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * from Specialties")){
            ObservableList<String> specialtiesList = FXCollections.observableArrayList();
            while (rs.next()){
                specialtiesList.add(rs.getString("Specialty"));
            }
            specialtyfield.setItems(specialtiesList);
        }
        catch(SQLException e){
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;
        }
    }
    @FXML
    private void handleSubmit(ActionEvent event) {
        String email = emailfield.getText();
        String password = passwordfield.getText();
        String name = namefield.getText();
        String confirmpassword = confirmpasswordfield.getText();
        if(specialtyfield.getValue()==null){
            showErrorAlert("Please Select a Specialty");
            return;
        }
        String specialty=specialtyfield.getValue();

        String status = "available";

        int count_checks=0;
        if(email.isEmpty() || password.isEmpty() || name.isEmpty() || confirmpassword.isEmpty()){
            showErrorAlert("Please fill all the fields");
            return;
        }
        if(password.length()<7){
            showErrorAlert("Password must be at least 7 characters");
            return;
        }
        if(name.matches(".*\\d.*")){
            showErrorAlert("Please enter a name. It should not have numbers");
            return;
        }
        if(!password.equals(confirmpassword)){
            showErrorAlert("Passwords do not match");
            return;
        }
        if(!email.contains("@clincare.com")){
            showErrorAlert("Please enter a valid email address");
            return;
        }
        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * from Specialties")){
            boolean specialtyexists=false;
            while(rs.next()){
                if(rs.getString("Specialty").equals(specialty)){
                    specialtyID = rs.getInt("SpecialtyID");
                    specialtyexists=true;
                    break;
                }
            }
            if(specialtyexists==false){
                showErrorAlert("This specialty does not exist");
                return;
            }
        }
        catch (Exception e) {
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;
        }
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT DoctorEmail FROM Doctors")) {

            while(rs.next()) {
                if(email.equals(rs.getString("DoctorEmail"))) {
                    showErrorAlert("Email already exists");
                    return;
                }
            }
        } catch (Exception e) {
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;
        }
        name="dr. "+name;
        try (Connection conn = DriverManager.getConnection(url);){
            String sql = "INSERT INTO Doctors (DoctorName, DoctorEmail, DoctorPassword,  SpecialtyID, Status) " +
                    "VALUES (?, ?, ?, ?, ?)";

            // Create a PreparedStatement
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // Set each parameter with the appropriate data type
            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, password);  // Should be hashed in production
            pstmt.setInt(4, specialtyID);
            pstmt.setString(5, status);
            pstmt.executeUpdate();
            emailfield.clear();
            passwordfield.clear();
            namefield.clear();
            confirmpasswordfield.clear();
            specialtyfield.setValue(null);
            showSuccessAlert(name+" has successfully been registered!");
        } catch (Exception e) {
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;

        }
        changePage(event, "AdminProfilePage.fxml", true);
    }
    @FXML
    private Button cancelbutton;
    @FXML
    private void cancel(ActionEvent event) {
        changePage(event, "AdminProfilePage.fxml", true);
    }


}
