package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.*;
import java.time.LocalDate;
import java.time.Period;

import static com.example.demo.changepage.changePage;
import static com.example.demo.doctors.getCurrentDoctorID;

public class Patientregistration {
    //similar to adminregisterpatient, but here doctorID is automatically the ID of the doctor
    //currently using the system
    String url = "jdbc:sqlite:Clinic_database.db";
    public void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    public void showSuccessAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText("Patient Registration successful!");
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private TextField emailfield;
    @FXML
    private TextField namefield;
    @FXML
    private TextField passwordfield;
    @FXML
    private TextField confirmpasswordfield;
    @FXML
    private ChoiceBox<String> genderchoicebox;
    @FXML
    private DatePicker dateofbirthfield;
    @FXML
    public void initialize() {
        try {
            ObservableList<String> genderList = FXCollections.observableArrayList();
            genderList.add("Male");
            genderList.add("Female");
            genderList.add("Other");
            genderchoicebox.setItems(genderList);

        } catch (Exception e) {
            System.out.println(e.getMessage());
            showErrorAlert(e.getMessage());
            return;
        }
    }
    @FXML
    private void handlesubmit(ActionEvent event) {
        String email = emailfield.getText();
        String password = passwordfield.getText();
        String name = namefield.getText();
        String confirmpassword = confirmpasswordfield.getText();
        if(genderchoicebox.getValue()==null){
            showErrorAlert("Please choose the suitable gender");
            return;
        }
        if(name.matches(".*\\d.*")){
            showErrorAlert("Please enter a valid name. It should not have numbers");
            return;
        }
        String gender=genderchoicebox.getValue();
        if(dateofbirthfield.getValue()==null){
            showErrorAlert("Date of Birth selection is empty!");
            return;
        }
        LocalDate dateofbirth = dateofbirthfield.getValue();
        if(email.isEmpty() || password.isEmpty() || name.isEmpty() || confirmpassword.isEmpty()){
            showErrorAlert("Please fill all the fields");
            return;
        }
        if(password.length()<7){
            showErrorAlert("Password must be at least 7 characters");
            return;
        }

        if(!password.equals(confirmpassword)){
            showErrorAlert("Passwords do not match");
            return;
        }
        if(!email.contains("@")){
            showErrorAlert("Please enter a valid email address");
            return;
        }
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT PatientEmail FROM Patients WHERE DoctorID="+getCurrentDoctorID())) {

            while(rs.next()) {
                if(email.equals(rs.getString("PatientEmail"))) {
                    showErrorAlert("Email already exists");
                    return;
                }
            }
        } catch (Exception e) {
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;
        }
        if(dateofbirth.isAfter(LocalDate.now())){
            showErrorAlert("Date of birth can't be in the future! Please enter a valid date");
            return;
        }
        int patientage= Period.between(dateofbirth, LocalDate.now()).getYears();
        try (Connection conn = DriverManager.getConnection(url);){
            String sql = "INSERT INTO Patients (PatientName, PatientEmail, Password, DoctorID, PatientAge, Gender, DateOfBirth) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)";


            PreparedStatement pstmt = conn.prepareStatement(sql);


            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, password);
            pstmt.setInt(4, getCurrentDoctorID());
            pstmt.setInt(5, patientage);
            pstmt.setString(6, gender);
            pstmt.setDate(7, java.sql.Date.valueOf(dateofbirth));


            pstmt.executeUpdate();
            emailfield.clear();
            passwordfield.clear();
            namefield.clear();
            confirmpasswordfield.clear();
            genderchoicebox.setValue(null);
            dateofbirthfield.setValue(null);
            showSuccessAlert("Patient: "+name+" has successfully been registered!");
        } catch (Exception e) {
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;

        }
        changePage(event, "doctorProfilepage.fxml", true);
    }
    @FXML
    private Button cancelbutton;
    @FXML
    private void cancel(ActionEvent event) {
        changePage(event, "doctorProfilepage.fxml", true);
    }

}
