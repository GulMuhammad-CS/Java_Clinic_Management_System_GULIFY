package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.*;

import static com.example.demo.changepage.changePage;
import static com.example.demo.doctors.getCurrentDoctorID;

public class MedicineRegistration {
    String url = "jdbc:sqlite:Clinic_database.db";
    public void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    public void showSuccessAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText("Medicine successfully added!");
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private TextField MedicineSaltField;
    @FXML
    private TextField MedicineNameField;
    @FXML
    private TextField MedicineDoseFormField;
    @FXML
    private TextField MedicineDoseStrenField;
    @FXML
    private void handleSubmit(ActionEvent event) {
        String medicineName = MedicineNameField.getText();
        String medicinesalt = MedicineSaltField.getText();
        String medicineform = MedicineDoseFormField.getText();
        String medicinestrength = MedicineDoseStrenField.getText();
        medicineName=medicineName.toLowerCase();
        medicinesalt=medicinesalt.toLowerCase();
        medicineform=medicineform.toLowerCase();
        if(medicineName.isEmpty() || medicinesalt.isEmpty() || medicineform.isEmpty() || medicinestrength.isEmpty()) {
            showErrorAlert("Please fill all fields!");
            return;
        }
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM Medicines")) {

            while(rs.next()) {
                if(medicineName.equals(rs.getString("MedicineName")) && medicinesalt.equals(rs.getString("MedicineSalt")) && medicinestrength.equals(rs.getString("MedicineDosageStrength")) && medicineform.equals(rs.getString("MedicineDosageForm"))) {
                    showErrorAlert("This medicine already exists");
                    return;
                }


            }
        } catch (Exception e) {
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;
        }
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();){
            String sql = "INSERT INTO Medicines (MedicineName, MedicineSalt, MedicineDosageStrength,  MedicineDosageForm) " +
                    "VALUES (?, ?, ?, ?)";

            // Create a PreparedStatement
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // Set each parameter with the appropriate data type
            pstmt.setString(1, medicineName);
            pstmt.setString(2, medicinesalt);
            pstmt.setString(3, medicinestrength);  // Should be hashed in production
            pstmt.setString(4, medicineform);
            pstmt.executeUpdate();
            MedicineNameField.clear();
            MedicineSaltField.clear();
            MedicineDoseFormField.clear();
            MedicineDoseStrenField.clear();
            showSuccessAlert(medicineName+" has successfully been registered!");
        } catch (Exception e) {
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;
        }
        changePage(event, "AdminProfilePage.fxml", true);
    }
    @FXML
    private Button cancelbutton;
    @FXML
    private void cancel(ActionEvent event) {
        changePage(event, "AdminProfilePage.fxml", true);
    }

}
