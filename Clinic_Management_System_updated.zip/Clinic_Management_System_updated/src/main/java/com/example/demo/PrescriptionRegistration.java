package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.*;
import java.time.LocalDate;

import static com.example.demo.changepage.changePage;
import static com.example.demo.doctors.getCurrentDoctorID;

public class PrescriptionRegistration {
    String url = "jdbc:sqlite:Clinic_database.db";
    public void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    public void showSuccessAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText("Prescription successfully added!");
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private TextField patientIDfield;
    @FXML
    private TextField MedicineNameField;
    @FXML
    private ChoiceBox dosageformchoicebox;
    @FXML
    private ChoiceBox dosagestrengthchoicebox;
    @FXML
    public void initialize(){
        //uses listener to wait for user to enter value for medicine name, then uses that name for a filter
        //to fetch possible distinct dosage forms
        //then uses another listener for the dosage form to fetch and display possible dosage strengths
        MedicineNameField.textProperty().addListener((observable, oldValue, newValue) -> {
            dosageformchoicebox.getItems().clear();
            dosagestrengthchoicebox.getItems().clear();
            if(!newValue.trim().isEmpty()){
                try(Connection conn = DriverManager.getConnection(url);
                    Statement stmt = conn.createStatement();
                    ResultSet rs = stmt.executeQuery("SELECT DISTINCT MedicineName, MedicineDosageForm FROM Medicines WHERE MedicineName = '"+MedicineNameField.getText().toLowerCase()+"';");){
                    ObservableList<String> DOSAGEFORMList = FXCollections.observableArrayList();
                    while (rs.next()){
                        DOSAGEFORMList.add(rs.getString("MedicineDosageForm"));
                    }
                    dosageformchoicebox.setItems(DOSAGEFORMList);
                }
                catch(SQLException e){
                    showErrorAlert("Database error: " + e.getMessage());
                    e.printStackTrace();
                    return;
                }
            }
        });
        dosageformchoicebox.valueProperty().addListener((observable, oldValue, newValue) -> {
            dosagestrengthchoicebox.getItems().clear();
            if(newValue != null){
                try(Connection conn = DriverManager.getConnection(url);
                    Statement stmt = conn.createStatement();
                    ResultSet rs = stmt.executeQuery("SELECT DISTINCT MedicineName, MedicineDosageForm, MedicineDosageStrength FROM Medicines WHERE MedicineName = '"+MedicineNameField.getText()+"' AND MedicineDosageForm = '"+dosageformchoicebox.getValue()+"';");){
                    ObservableList<String> DOSAGESTRENGTHList = FXCollections.observableArrayList();
                    while (rs.next()){
                        DOSAGESTRENGTHList.add(rs.getString("MedicineDosageStrength"));
                    }
                    dosagestrengthchoicebox.setItems(DOSAGESTRENGTHList);
                }
                catch(SQLException e){
                    showErrorAlert("Database error: " + e.getMessage());
                    e.printStackTrace();
                    return;
                }
            }
        });
    }
    @FXML
    private void handlesubmit(ActionEvent event) {
        int doctorID = getCurrentDoctorID();
        LocalDate currentdate=LocalDate.now();
        if(patientIDfield.getText()==null || patientIDfield.getText().trim().isEmpty()){
            showErrorAlert("Patient ID is empty!");
            return;
        }
        int patientID;
        try{
            patientID=Integer.parseInt(patientIDfield.getText());
        }
        catch(NumberFormatException e){
            showErrorAlert("Patient ID is invalid! Please enter a valid Integer!");
            return;
        }
        String medicineName = MedicineNameField.getText();
        if(medicineName.trim().isEmpty()){
            showErrorAlert("Medicine Name is empty!");
            return;
        }
        boolean medicineExists=false;
        try(Connection conn=DriverManager.getConnection(url);
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT MedicineName FROM Medicines WHERE MedicineName='"+medicineName+"';")){
            while(rs.next()){
                if(medicineName.equalsIgnoreCase(rs.getString("MedicineName"))){
                    medicineExists=true;
                }
            }
        }
        catch(Exception e){
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;
        }
        if(!medicineExists){
            showErrorAlert("Medicine does not exist!");
            return;
        }
        if(dosageformchoicebox.getValue()==null){
            showErrorAlert("Please choose a dosage form!");
            return;
        }
        if(dosagestrengthchoicebox.getValue()==null){
            showErrorAlert("Please choose a dosage strength!");
            return;
        }
        String dosagestrength=dosagestrengthchoicebox.getValue().toString();
        String dosageform=dosageformchoicebox.getValue().toString();
        int medicineID=-1;
        try(Connection conn=DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT MedicineID, MedicineName, MedicineDosageForm, MedicineDosageStrength FROM Medicines WHERE MedicineName='"+medicineName+"' AND MedicineDosageForm = '"+dosageform+"' AND MedicineDosageStrength='"+dosagestrength+"';");){
            while(rs.next()){
                medicineID=rs.getInt("MedicineID");
            }
        }
        catch(Exception e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
            return;
        }
        if(medicineID==-1){
            showErrorAlert("Medicine does not exist!");
            return;
        }
        boolean patientExists=false;
        try(Connection conn=DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT PatientID FROM Patients WHERE DoctorID='"+getCurrentDoctorID()+"';");){
            while(rs.next()){
                if(patientID==rs.getInt("PatientID")){
                    patientExists = true;
                    break;
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
            return;
        }
        if(!patientExists){
            showErrorAlert("Patient does not exist!");
            return;
        }
        try(Connection conn=DriverManager.getConnection(url)){
            String sql="INSERT INTO Prescriptions (DoctorID, PatientID, PrescriptionDate, MedicineID) VALUES (?, ?, ?, ?)";
            PreparedStatement pstmt=conn.prepareStatement(sql);
            pstmt.setInt(1, doctorID);
            pstmt.setInt(2, patientID);
            pstmt.setDate(3, java.sql.Date.valueOf(currentdate));
            pstmt.setInt(4, medicineID);
            pstmt.executeUpdate();
            showSuccessAlert("Prescription added!");
            patientIDfield.clear();
            MedicineNameField.clear();
            dosageformchoicebox.setValue(null);
            dosagestrengthchoicebox.setValue(null);
        }
        catch(Exception e){
            e.printStackTrace();
            showErrorAlert("Database error: " + e.getMessage());
            return;
        }
        changePage(event, "doctorProfilepage.fxml", true);
    }
    @FXML
    private Button cancelbutton;
    @FXML
    private void cancel(ActionEvent event) {
        changePage(event, "doctorProfilepage.fxml", true);
    }

}
