package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.stage.Stage;

import java.sql.*;
import java.time.LocalDate;

import static com.example.demo.changepage.changePage;
import static com.example.demo.doctors.getCurrentDoctorID;
import static com.example.demo.patients.getcurrentpatientID;

public class AppointmentRequest {

    String url = "jdbc:sqlite:Clinic_database.db";
    public void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    public void showSuccessAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText("Appointment Request successful!");
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private ChoiceBox<String> doctorspecialtychoicebox;
    @FXML
    private ChoiceBox<String> doctornamechoicebox;
    @FXML
    private DatePicker appointmentDateField;
    @FXML
    private ChoiceBox<String> appointmentTimeField;
    String appointmentstatus="requested";
    int patientID=getcurrentpatientID();
    int chosenspecialtyID;
    int doctorid;
    @FXML
    public void initialize(){
        try{
            ObservableList<String> timeList= FXCollections.observableArrayList();
            timeList.add("9:00");
            timeList.add("10:00");
            timeList.add("11:00");
            timeList.add("12:00");
            timeList.add("13:00");
            timeList.add("14:00");
            timeList.add("15:00");
            timeList.add("16:00");
            timeList.add("17:00");
            timeList.add("18:00");
            appointmentTimeField.setItems(timeList);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            showErrorAlert(e.getMessage());
            return;
        }

        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM Specialties");){
            ObservableList<String> specialtiesList = FXCollections.observableArrayList();
            while (rs.next()){
                specialtiesList.add(rs.getString("Specialty"));
            }
            doctorspecialtychoicebox.setItems(specialtiesList);
        }
        catch(SQLException e){
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;
        }
        doctorspecialtychoicebox.valueProperty().addListener((observable, oldValue, newValue) -> {
            doctornamechoicebox.getItems().clear();
            if(newValue != null){
                try(Connection conn = DriverManager.getConnection(url)){
                    // Get the specialtyID for the selected specialty
                    String specialtyQuery = "SELECT SpecialtyID FROM Specialties WHERE Specialty ='"+newValue+"';";
                    Statement stmt = conn.createStatement();
                    ResultSet specialtyRs = stmt.executeQuery(specialtyQuery);

                    if(specialtyRs.next()) {
                        chosenspecialtyID = specialtyRs.getInt("SpecialtyID");

                        String doctorQuery = "SELECT DoctorName FROM Doctors WHERE Status='available' AND SpecialtyID = ?";
                        PreparedStatement pstmt2 = conn.prepareStatement(doctorQuery);
                        pstmt2.setInt(1, chosenspecialtyID);
                        ResultSet doctorRs = pstmt2.executeQuery();

                        ObservableList<String> doctorList = FXCollections.observableArrayList();
                        while (doctorRs.next()){
                            doctorList.add(doctorRs.getString("DoctorName"));
                        }
                        doctornamechoicebox.setItems(doctorList);
                    }
                }
                catch(SQLException e){
                    showErrorAlert("Database error: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        });
    }
    @FXML
    private void handleSubmit(ActionEvent event) {


        if(doctorspecialtychoicebox.getValue()==null){
            showErrorAlert("Please choose a specialty!");
            return;
        }
        String doctorspecialty=doctorspecialtychoicebox.getValue();
        if(doctornamechoicebox.getValue()==null){
            showErrorAlert("Please choose a doctor!");
            return;
        }
        String doctorname=doctornamechoicebox.getValue();
        if(appointmentDateField.getValue()==null){
            showErrorAlert("Appointment Date is empty!");
            return;
        }
        LocalDate appointmentDate = appointmentDateField.getValue();
        if(appointmentTimeField.getValue()==null){
            showErrorAlert("Please select an appointment time!");
            return;
        }
        String appointmentTime = appointmentTimeField.getValue().toString();
        if(appointmentDate.isBefore(LocalDate.now())){
            showErrorAlert("Appointment Date is older than current date! Please choose a date after today.");
            return;
        }

        try(Connection conn=DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT DoctorID, DoctorName, SpecialtyID FROM Doctors WHERE DoctorName='"+doctorname+"' AND SpecialtyID="+chosenspecialtyID+";");){
            while(rs.next()){
                doctorid=rs.getInt("DoctorID");
            }
        }
        catch(Exception e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
            return;
        }
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT AppointmentDate, AppointmentTime FROM Appointments WHERE (AppointmentStatus='upcoming'  OR AppointmentStatus='requested') AND DoctorID="+doctorid+";")) {

            while(rs.next()) {
                Date sqlDate = rs.getDate("AppointmentDate");
                LocalDate localDate = null;
                if (sqlDate != null) {
                    localDate = sqlDate.toLocalDate();
                }
                if(localDate.equals(appointmentDate) && appointmentTime.equals(rs.getString("AppointmentTime"))) {
                    showErrorAlert("This time slot has already been booked!");
                    return;
                }
            }
        } catch (Exception e) {
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;
        }
        try (Connection conn = DriverManager.getConnection(url);){
            String sql = "INSERT INTO Appointments (DoctorID, PatientID, AppointmentDate, AppointmentTime, AppointmentStatus) " +
                    "VALUES (?, ?, ?, ?, ?)";


            PreparedStatement pstmt = conn.prepareStatement(sql);


            pstmt.setInt(1, doctorid);
            pstmt.setInt(2, patientID);
            pstmt.setDate(3, java.sql.Date.valueOf(appointmentDate));  // Should be hashed in production
            pstmt.setString(4, appointmentTime);
            pstmt.setString(5, appointmentstatus);


            pstmt.executeUpdate();
            doctornamechoicebox.getItems().clear();
            doctorspecialtychoicebox.getItems().clear();
            appointmentDateField.setValue(null);
            appointmentTimeField.setValue(null);
            showSuccessAlert("Appointment for "+appointmentDate+" at "+appointmentTime+" has successfully been requested!");
        } catch (Exception e) {
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;

        }
        changePage(event, "patientProfilepage.fxml", true);
    }
    @FXML
    private void cancel(ActionEvent event) {
        changePage(event, "patientProfilepage.fxml", true);
    }
}
