package com.example.demo;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

import static com.example.demo.changepage.changePage;

public class ChooseUserpage {
    //page to navigate to various login pages
    @FXML
    public void showErrorAlert(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private void doctorslogin(ActionEvent event) {
        changePage(event, "doctorLoginpage.fxml", false);
    }
    @FXML
    private void adminslogin(ActionEvent event) {
        changePage(event, "adminLoginpage.fxml", false);
    }
    @FXML
    private void patientslogin(ActionEvent event) {
        changePage(event, "PatientLoginPage.fxml", false);
    }
}
