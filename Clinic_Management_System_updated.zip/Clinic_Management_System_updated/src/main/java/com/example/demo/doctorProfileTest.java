//package com.example.demo;
//import static com.example.demo.ClinicApplication.createdatabase;
//import static com.example.demo.doctors.setCurrentDoctorID;
//import static javafx.beans.binding.Bindings.when;
//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.fail;
//import static org.mockito.Mockito.mock;
//import static org.mockito.Mockito.when;
//import static org.mockito.Mockito.verify;
//import static org.mockito.Mockito.any;
//import static org.mockito.Mockito.anyString;
//import static org.mockito.Mockito.contains;
//import static org.mockito.Mockito.doReturn;
//import org.mockito.MockedStatic;
//
//import javafx.collections.FXCollections;
//import javafx.event.ActionEvent;
//import javafx.scene.control.TableView;
//import org.junit.Before;
//import org.junit.jupiter.api.*;
//import org.junit.jupiter.api.extension.ExtendWith;
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.SQLException;
//import java.sql.Statement;
//import java.time.LocalDate;
//
//public class doctorProfileTest {
//    private Doctorprofile doctorprofile;
//    private static final String TEST_DB = "jdbc:sqlite:Test_Clinic_database.db";
//    private static final int TEST_DOCTOR_ID = 999;
//    @BeforeAll
//    public static void setupdatabase(){
//        createdatabase();
//        setCurrentDoctorID(TEST_DOCTOR_ID);
//    }
//    @BeforeEach
//    public void setUp() {
//        doctorprofile = new Doctorprofile();
//    }
//    @AfterAll
//    public static void tearDown() {
//        // Clean up test database
//        try (Connection conn = DriverManager.getConnection(TEST_DB);
//             Statement stmt = conn.createStatement()) {
//            stmt.execute("DROP TABLE IF EXISTS Doctors");
//            stmt.execute("DROP TABLE IF EXISTS Patients");
//            stmt.execute("DROP TABLE IF EXISTS Appointments");
//            stmt.execute("DROP TABLE IF EXISTS Medicines");
//            stmt.execute("DROP TABLE IF EXISTS Prescriptions");
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//    }
//    @Test
//    public void testLoadPatientsTable() {
//        // Insert test patient
//        try (Connection conn = DriverManager.getConnection(TEST_DB);
//             Statement stmt = conn.createStatement()) {
//            stmt.execute("INSERT INTO Patients VALUES (1, 'patient@test.com', 'Test Patient', 30, 'Male', '1993-01-01', " + TEST_DOCTOR_ID + ")");
//        } catch (SQLException e) {
//            fail("Failed to insert test patient: " + e.getMessage());
//        }
//
//        // Mock TableView and ObservableList
//        doctorprofile.patientTableView = new TableView<>();
//        doctorprofile.patientslist = FXCollections.observableArrayList();
//        doctorprofile.initializepatientTableView();
//
//        // Load the table
//        doctorprofile.loadpatientTableView();
//
//        // Verify data was loaded
//        assertEquals(1, doctorprofile.patientslist.size());
//        assertEquals("Test Patient", doctorprofile.patientslist.get(0).getName());
//    }
//
//    @Test
//    public void testDeletePatient() {
//        // Setup
//        doctorprofile.patientTableView = new TableView<>();
//        doctorprofile.patientslist = FXCollections.observableArrayList();
//
//        // Add a test patient to delete
//        patients testPatient = new patients(2, "delete@test.com", "Delete Me", 25, "Female", LocalDate.of(1998, 5, 15), TEST_DOCTOR_ID);
//        doctorprofile.patientslist.add(testPatient);
//
//        try (Connection conn = DriverManager.getConnection(TEST_DB);
//             Statement stmt = conn.createStatement()) {
//            stmt.execute("INSERT INTO Patients VALUES (2, 'delete@test.com', 'Delete Me', 25, 'Female', '1998-05-15', " + TEST_DOCTOR_ID + ")");
//        } catch (SQLException e) {
//            fail("Failed to insert test patient: " + e.getMessage());
//        }
//
//        // Mock selection model
//        TableView.TableViewSelectionModel<patients> selectionModel = mock(TableView.TableViewSelectionModel.class);
//        when(selectionModel.getSelectedItem()).thenReturn(testPatient);
//        doctorprofile.patientTableView.setSelectionModel(selectionModel);
//
//        // Perform deletion
//        doctorprofile.deletepatient(new ActionEvent());
//
//        // Verify patient was removed
//        assertEquals(0, doctorprofile.patientslist.size());
//
//        // Verify from database
//        try (Connection conn = DriverManager.getConnection(TEST_DB);
//             Statement stmt = conn.createStatement();
//             var rs = stmt.executeQuery("SELECT COUNT(*) FROM Patients WHERE PatientID = 2")) {
//            rs.next();
//            assertEquals(0, rs.getInt(1));
//        } catch (SQLException e) {
//            fail("Failed to verify patient deletion: " + e.getMessage());
//        }
//    }
//
//
//}
