package com.example.demo;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.event.ActionEvent;
import com.example.demo.medicines;
import com.example.demo.specialties;
import com.example.demo.doctors;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.sql.*;
import java.time.LocalDate;

import static com.example.demo.logout.Plogout;
import static com.example.demo.changepage.changePage;
import static com.example.demo.doctors.getCurrentDoctorID;

public class AdminProfile {
    @FXML
    private Button removedoctorbutton;
    @FXML
    private Button removemedicinebutton;
    @FXML
    private Button removespecialtybutton;
    public void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    //doctors part
    @FXML
    private TableView<doctors> doctorTableView;
    @FXML
    private TableColumn<doctors, Integer> DoctorId;
    @FXML
    private TableColumn<doctors, String> DoctorName;
    @FXML
    private TableColumn<doctors, String> DoctorEmail;
    @FXML
    private TableColumn<doctors, Integer>SpecialtyId;
    @FXML
    private TableColumn<doctors, String> DoctorStatus;
    @FXML
    private ObservableList<doctors> doctorsList = FXCollections.observableArrayList();
    @FXML
    public void initializeDoctorsTable(){
        DoctorId.setCellValueFactory(cellData ->
                new SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        DoctorName.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getName()));
        DoctorEmail.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getEmail()));
        SpecialtyId.setCellValueFactory(cellData ->
                new SimpleIntegerProperty(cellData.getValue().getSpecialtyId()).asObject());
        DoctorStatus.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getStatus()));
    }
    @FXML
    private void showDoctorsTable(){
        doctorsList.clear();
        initializeDoctorsTable();
        loadDoctorsTable();
        specialtyTableView.setVisible(false);
        specialtyList.clear();
        medicineTableView.setVisible(false);
        patienttableview.setVisible(false);
        medicineList.clear();
        doctorTableView.setVisible(true);
    }
    @FXML
    private void loadDoctorsTable(){
        String url="jdbc:sqlite:Clinic_database.db";
        String query = "SELECT * FROM Doctors";

        try(Connection conn = DriverManager.getConnection(url);
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(query)){
            while (rs.next()){
                doctorsList.add(new doctors(
                        rs.getInt("DoctorID"),
                        rs.getString("DoctorName"),
                        rs.getString("DoctorEmail"),
                        rs.getInt("SpecialtyID"),
                        rs.getString("Status"))
                );
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
        }
        doctorTableView.setItems(doctorsList);
    }
    //doctors part done

    //Medicines part

    @FXML
    private TableView<medicines> medicineTableView;
    @FXML
    private TableColumn<medicines, Integer> MedicineID;
    @FXML
    private TableColumn<medicines, String> MedicineName;
    @FXML
    private TableColumn<medicines, String> MedicineSalt;
    @FXML
    private TableColumn<medicines, String> MedicineDosageForm;
    @FXML
    private TableColumn<medicines, String> MedicineDosageStrength;
    @FXML
    private ObservableList<medicines> medicineList = FXCollections.observableArrayList();
    @FXML
    public void initializeMedicineTable(){
        MedicineID.setCellValueFactory(cellData ->
                new SimpleIntegerProperty(cellData.getValue().getMedicineID()).asObject());
        MedicineName.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getMedicineName()));
        MedicineSalt.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getMedicineSalt()));
        MedicineDosageForm.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getMedicineDosageForm()));
        MedicineDosageStrength.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getMedicineDosageStrength()));
    }
    @FXML
    private void loadMedicineTable(){
        String url="jdbc:sqlite:Clinic_database.db";
        String query = "SELECT * FROM Medicines";

        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query)){
            while (rs.next()){
                medicineList.add(new medicines(
                        rs.getInt("MedicineID"),
                        rs.getString("MedicineName"),
                        rs.getString("MedicineSalt"),
                        rs.getString("MedicineDosageForm"),
                        rs.getString("MedicineDosageStrength"))
                );
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
        }
        medicineTableView.setItems(medicineList);
    }
    @FXML
    private void showmedicineTable(){
        medicineList.clear();
        initializeMedicineTable();
        loadMedicineTable();
        specialtyTableView.setVisible(false);
        specialtyList.clear();
        doctorTableView.setVisible(false);
        doctorsList.clear();
        medicineTableView.setVisible(true);
        patienttableview.setVisible(false);
    }
    //medicines part done
    //specialties part
    @FXML
    private TableView<specialties> specialtyTableView;
    @FXML
    private TableColumn<specialties, Integer> PspecialtyID;
    @FXML
    private TableColumn<specialties, String> Specialty;
    @FXML
    private ObservableList<specialties> specialtyList = FXCollections.observableArrayList();
    @FXML
    private void initializespecialtytable(){
        PspecialtyID.setCellValueFactory(cellData ->
                new SimpleIntegerProperty(cellData.getValue().getSpecialtyId()).asObject());
        Specialty.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getSpecialty()));
    }
    @FXML
    private void loadspecialtyTable(){
        String url="jdbc:sqlite:Clinic_database.db";
        String query = "SELECT * FROM Specialties";
        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query)){
            while (rs.next()){
                specialtyList.add(new specialties(
                        rs.getInt("SpecialtyID"),
                        rs.getString("Specialty")

                ));
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
        }
        specialtyTableView.setItems(specialtyList);
    }
    @FXML
    private void showspecialtyTable(){
        specialtyList.clear();
        initializespecialtytable();
        loadspecialtyTable();
        doctorTableView.setVisible(false);
        doctorsList.clear();
        medicineTableView.setVisible(false);
        medicineList.clear();
        specialtyTableView.setVisible(true);
        patienttableview.setVisible(false);

    }
    //specialties part done
    @FXML
    public void initialize() {

        // Set up all table columns first
        initializeDoctorsTable();
        initializeMedicineTable();
        initializespecialtytable();
        initializepatientTableView();
        doctorTableView.managedProperty().bind(doctorTableView.visibleProperty());
        medicineTableView.managedProperty().bind(medicineTableView.visibleProperty());
        specialtyTableView.managedProperty().bind(specialtyTableView.visibleProperty());
        patienttableview.managedProperty().bind(patienttableview.visibleProperty());
        // Make the doctors table visible by default
        doctorTableView.setVisible(false);
        medicineTableView.setVisible(false);
        specialtyTableView.setVisible(false);
        patienttableview.setVisible(false);

        // Load the data for the visible table
        loadDoctorsTable();


    }
    //patients part
    @FXML
    private TableView<patients> patienttableview;
    @FXML
    private TableColumn<patients, Integer> PatientID;
    @FXML
    private TableColumn<patients, String> PatientName;
    @FXML
    private TableColumn<patients, String> PatientEmail;
    @FXML
    private TableColumn<patients, String> Gender;
    @FXML
    private TableColumn<patients, Integer> PatientAge;
    @FXML
    private TableColumn<patients, LocalDate> DateOfBirth;
    @FXML
    private TableColumn<patients, Integer> DoctorID;
    @FXML
    private Button removepatientsbutton;
    @FXML
    private ObservableList<patients> patientslist= FXCollections.observableArrayList();
    @FXML
    public void initializepatientTableView() {
        PatientID.setCellValueFactory(cellData->
                new SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        PatientName.setCellValueFactory(cellData->
                new SimpleStringProperty(cellData.getValue().getName()));
        PatientEmail.setCellValueFactory(cellData->
                new SimpleStringProperty(cellData.getValue().getEmail()));
        Gender.setCellValueFactory(cellData->
                new SimpleStringProperty(cellData.getValue().getGender()));
        PatientAge.setCellValueFactory(cellData->
                new SimpleIntegerProperty(cellData.getValue().getAge()).asObject());
        DateOfBirth.setCellValueFactory(cellData->
                new SimpleObjectProperty<>(cellData.getValue().getDOB()));
        DoctorID.setCellValueFactory(cellData->
                new SimpleIntegerProperty(cellData.getValue().getDoctorId()).asObject());
    }
    @FXML
    public void loadpatientTableView() {
        String url="jdbc:sqlite:Clinic_database.db";
        String query = "SELECT * FROM Patients";
        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query)){
            while (rs.next()){
                Date sqlDate = rs.getDate("DateOfBirth");
                LocalDate localDate = null;
                if (sqlDate != null) {
                    localDate = sqlDate.toLocalDate(); // This converts sql.Date to LocalDate
                }
                patientslist.add(new patients(
                        rs.getInt("PatientID"),
                        rs.getString("PatientEmail"),
                        rs.getString("PatientName"),
                        rs.getInt("PatientAge"),
                        rs.getString("Gender"),
                        localDate,
                        rs.getInt("DoctorID")

                ));
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
        }
        patienttableview.setItems(patientslist);
    }
    @FXML
    private void showPatientsTable(){
        patientslist.clear();
        initializepatientTableView();
        loadpatientTableView();
        patienttableview.setVisible(true);
        medicineTableView.setVisible(false);
        specialtyTableView.setVisible(false);
        doctorTableView.setVisible(false);
    }
    //registration pages
    //doctor registration
    @FXML
    private void gotodoctorregistration(ActionEvent event){
        changePage(event, "doctorRegistrationPage.fxml", false);
    }

    //medicine registration
    @FXML
    private void gotomedicineregistration(ActionEvent event){
        changePage(event, "MedicineRegistrationPage.fxml", false);
    }

    //specialties registration
    @FXML
    private void gotospecialtyregistration(ActionEvent event){
        changePage(event, "SpecialtyRegistrationPage.fxml", false);
    }
    @FXML
    private void addadmin(ActionEvent event){
        changePage(event, "adminregistrationpage.fxml", false);
    }
    @FXML
    private void addpatient(ActionEvent event){
        changePage(event, "adminregisterpatientpage.fxml", false);
    }
    @FXML
    private void deletepatient(ActionEvent event) {
        String url = "jdbc:sqlite:Clinic_database.db";
        patients selectedPatient = patienttableview.getSelectionModel().getSelectedItem();

        if (selectedPatient != null) {
            String query = "DELETE FROM Patients WHERE PatientID='" + selectedPatient.getId() + "'";
            try (Connection conn = DriverManager.getConnection(url);
                 Statement stmt = conn.createStatement()) {
                stmt.execute("PRAGMA foreign_keys = ON;");
                int rowsAffected = stmt.executeUpdate(query);
                if (rowsAffected > 0) {
                    patientslist.remove(selectedPatient);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                showErrorAlert(e.getMessage());
            }
        } else {
            showErrorAlert("Please select a patient to delete.");
        }
    }
    @FXML
    private void deletedoctor(ActionEvent event) {
        String url = "jdbc:sqlite:Clinic_database.db";
        doctors selecteddoctor = doctorTableView.getSelectionModel().getSelectedItem();

        if (selecteddoctor != null) {
            String query = "DELETE FROM Doctors WHERE DoctorID='" + selecteddoctor.getId() + "'";
            try (Connection conn = DriverManager.getConnection(url);
                 Statement stmt = conn.createStatement()) {
                stmt.execute("PRAGMA foreign_keys = ON;");
                int rowsAffected = stmt.executeUpdate(query);
                if (rowsAffected > 0) {
                    doctorsList.remove(selecteddoctor);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                showErrorAlert(e.getMessage());
            }
        } else {
            showErrorAlert("Please select a doctor to delete.");
        }
    }
    @FXML
    private void deletemedicine(ActionEvent event) {
        String url = "jdbc:sqlite:Clinic_database.db";
        medicines selectedmedicine = medicineTableView.getSelectionModel().getSelectedItem();

        if (selectedmedicine != null) {
            String query = "DELETE FROM Medicines WHERE MedicineID='" + selectedmedicine.getMedicineID() + "'";
            try (Connection conn = DriverManager.getConnection(url);
                 Statement stmt = conn.createStatement()) {
                stmt.execute("PRAGMA foreign_keys = ON;");
                int rowsAffected = stmt.executeUpdate(query);
                if (rowsAffected > 0) {
                    medicineList.remove(selectedmedicine);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                showErrorAlert(e.getMessage());
            }
        } else {
            showErrorAlert("Please select a medicine to delete.");
        }
    }
    @FXML
    private void deletespecialty(ActionEvent event) {
        String url = "jdbc:sqlite:Clinic_database.db";
        specialties selectedspecialty = specialtyTableView.getSelectionModel().getSelectedItem();

        if (selectedspecialty != null) {
            String query = "DELETE FROM Specialties WHERE SpecialtyID='" + selectedspecialty.getSpecialtyId() + "'";
            try (Connection conn = DriverManager.getConnection(url);
                 Statement stmt = conn.createStatement()) {
                stmt.execute("PRAGMA foreign_keys = ON;");
                int rowsAffected = stmt.executeUpdate(query);
                if (rowsAffected > 0) {
                    specialtyList.remove(selectedspecialty);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                showErrorAlert(e.getMessage());
            }
        } else {
            showErrorAlert("Please select a specialty to delete.");
        }
    }

    @FXML
    private void logout(ActionEvent event){
        Plogout(event);
    }

}
