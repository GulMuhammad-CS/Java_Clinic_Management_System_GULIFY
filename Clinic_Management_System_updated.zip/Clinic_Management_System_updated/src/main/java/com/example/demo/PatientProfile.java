package com.example.demo;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.stage.Stage;

import java.sql.*;
import java.time.LocalDate;

import static com.example.demo.changepage.changePage;
import static com.example.demo.doctors.getCurrentDoctorID;
import static com.example.demo.doctors.setCurrentDoctorID;
import static com.example.demo.logout.Plogout;
import static com.example.demo.patients.getcurrentpatientID;
import static com.example.demo.patients.setcurrentpatientID;

public class PatientProfile {
    public void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private TableView<patientAppointments> patientAppointmentsTableView;
    @FXML
    private TableColumn<patientAppointments, Integer> AppointmentID;
    @FXML
    private TableColumn<patientAppointments, String> DoctorName;
    @FXML
    private TableColumn<patientAppointments, LocalDate> AppointmentDate;
    @FXML
    private TableColumn<patientAppointments, String> AppointmentTime;
    @FXML
    private ObservableList<patientAppointments> patientAppointmentsList= FXCollections.observableArrayList();
    @FXML
    public void initializeappointmenttable(){
        AppointmentID.setCellValueFactory(cellData->
                new SimpleIntegerProperty(cellData.getValue().getAppointmentID()).asObject());
        DoctorName.setCellValueFactory(cellData->
                new SimpleStringProperty(cellData.getValue().getDoctorName()));
        AppointmentDate.setCellValueFactory(cellData->
                new SimpleObjectProperty<>(cellData.getValue().getAppointmentDate()));
        AppointmentTime.setCellValueFactory(cellData->
                new SimpleStringProperty(cellData.getValue().getAppointmentTime()));
    }
    @FXML
    private void loadappointmenttable(){
        String url="jdbc:sqlite:Clinic_database.db";
        String query="SELECT Appointments.AppointmentID, Doctors.DoctorName, "
                +"Appointments.AppointmentDate, Appointments.AppointmentTime FROM Appointments JOIN Doctors "+
                "ON Appointments.DoctorID = Doctors.DoctorID WHERE Appointments.AppointmentStatus='upcoming' "+
                "AND Appointments.PatientID="+getcurrentpatientID()+";";
        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query)){
            while (rs.next()){
                Date sqlDate = rs.getDate("AppointmentDate");
                LocalDate localDate = null;
                if (sqlDate != null) {
                    localDate = sqlDate.toLocalDate(); // This converts sql.Date to LocalDate
                }
                patientAppointmentsList.add(new patientAppointments(
                        rs.getInt("AppointmentID"),
                        rs.getString("DoctorName"),
                        localDate,
                        rs.getString("AppointmentTime")

                ));

            }

        }
        catch(Exception e){
            e.printStackTrace();
            showErrorAlert("Something went wrong!"+e.getMessage());
            return;
        }
        try(Connection conn=DriverManager.getConnection(url);){
            String removeoldappointmentquery="UPDATE Appointments SET AppointmentStatus='completed' WHERE AppointmentStatus='upcoming' AND AppointmentDate<?";
            PreparedStatement pstmt=conn.prepareStatement(removeoldappointmentquery);
            pstmt.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
            pstmt.executeUpdate();
        }
        catch(SQLException e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
            return;
        }
        patientAppointmentsTableView.setItems(patientAppointmentsList);
    }
    @FXML
    private void showappointmenttable(){
        patientAppointmentsList.clear();
        initializeappointmenttable();
        loadappointmenttable();
        patientPrescriptionsTableView.setVisible(false);
        patientAppointmentsTableView.setVisible(true);
    }
    @FXML
    private TableView<patientPrescriptions> patientPrescriptionsTableView;
    @FXML
    private TableColumn<patientPrescriptions, Integer> PrescriptionID;
    @FXML
    private TableColumn<patientPrescriptions, String> PDoctorName;
    @FXML
    private TableColumn<patientPrescriptions, String> MedicineName;
    @FXML
    private TableColumn<patientPrescriptions, String> MedicineSalt;
    @FXML
    private TableColumn<patientPrescriptions, String> MedicineDosageForm;
    @FXML
    private TableColumn<patientPrescriptions, String> MedicineDosageStrength;
    @FXML
    private TableColumn<patientPrescriptions, LocalDate> PrescriptionDate;
    @FXML
    private ObservableList<patientPrescriptions> patientPrescriptionsList= FXCollections.observableArrayList();
    @FXML
    public void initializepatientprescriptiontable(){
        PrescriptionID.setCellValueFactory(cellData ->
                new SimpleIntegerProperty(cellData.getValue().getPrescriptionID()).asObject());
        PDoctorName.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getDoctorName()));
        MedicineName.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getMedicineName()));
        MedicineSalt.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getMedicineSalt()));
        MedicineDosageForm.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getMedicineDosageForm()));
        MedicineDosageStrength.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getMedicineDosageStrength()));
        PrescriptionDate.setCellValueFactory(cellData ->
                new SimpleObjectProperty<>(cellData.getValue().getPrescriptionDate()));
    }
    @FXML
    private void loadpatientprescriptiontable(){
        String url="jdbc:sqlite:Clinic_database.db";
        String query="SELECT Prescriptions.PrescriptionID, Doctors.DoctorName, Medicines.MedicineName, "
                +"Medicines.MedicineSalt, Medicines.MedicineDosageForm, Medicines.MedicineDosageStrength, "
                +"Prescriptions.PrescriptionDate FROM Prescriptions JOIN Doctors ON Prescriptions.DoctorID="+
                "Doctors.DoctorID JOIN Medicines ON Medicines.MedicineID=Prescriptions.MedicineID WHERE Prescriptions.PatientID="+getcurrentpatientID()+";";
        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query)){
            while (rs.next()){
                Date sqlDate = rs.getDate("PrescriptionDate");
                LocalDate localDate = null;
                if (sqlDate != null) {
                    localDate = sqlDate.toLocalDate();
                }
                patientPrescriptionsList.add(new patientPrescriptions(
                        rs.getInt("PrescriptionID"),
                        rs.getString("DoctorName"),
                        rs.getString("MedicineName"),
                        rs.getString("MedicineSalt"),
                        rs.getString("MedicineDosageForm"),
                        rs.getString("MedicineDosageStrength"),
                        localDate


                ));

            }

        }
        catch(Exception e){
            e.printStackTrace();
            showErrorAlert("Something went wrong!"+e.getMessage());
            return;
        }
        patientPrescriptionsTableView.setItems(patientPrescriptionsList);
    }
    @FXML
    private void showpatientprescriptiontable(){
        patientPrescriptionsList.clear();
        initializepatientprescriptiontable();
        loadpatientprescriptiontable();
        patientAppointmentsTableView.setVisible(false);
        patientPrescriptionsTableView.setVisible(true);
    }
    @FXML
    private Label patientidlabel;
    @FXML
    private Label namelabel;
    @FXML
    private Label genderlabel;
    String name="";
    String gender="";
    int id=0;
    @FXML
    private void loadLabels(){

        String url="jdbc:sqlite:Clinic_database.db";
        String query = "SELECT * FROM Patients WHERE PatientID="+getcurrentpatientID();
        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query)){
            while (rs.next()){
                id =rs.getInt("PatientID");
                name =rs.getString("PatientName");
                gender =rs.getString("Gender");


            }
            namelabel.setText("Name: "+name);
            genderlabel.setText("Gender: "+gender);
            patientidlabel.setText("Patient ID: "+id);

        }
        catch (SQLException e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
        }
    }
    @FXML
    public void initialize(){
        initializepatientprescriptiontable();
        initializeappointmenttable();
        loadLabels();
        patientAppointmentsTableView.managedProperty().bind(patientAppointmentsTableView.visibleProperty());
        patientPrescriptionsTableView.managedProperty().bind(patientPrescriptionsTableView.visibleProperty());
        patientAppointmentsTableView.setVisible(false);
        patientPrescriptionsTableView.setVisible(false);

    }
    @FXML
    private void cancelappointment(ActionEvent event) {
        String url = "jdbc:sqlite:Clinic_database.db";
        patientAppointments selectedappointment = patientAppointmentsTableView.getSelectionModel().getSelectedItem();

        if (selectedappointment != null) {
            String query = "UPDATE Appointments SET AppointmentStatus='cancelled' WHERE AppointmentID='" + selectedappointment.getAppointmentID() + "'";
            try (Connection conn = DriverManager.getConnection(url);
                 Statement stmt = conn.createStatement()) {
                int rowsAffected = stmt.executeUpdate(query);
                if (rowsAffected > 0) {
                    patientAppointmentsList.remove(selectedappointment);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                showErrorAlert(e.getMessage());
            }
        } else {
            showErrorAlert("Please select an appointment to cancel.");
        }
    }
    @FXML
    private void requestAppointment(ActionEvent event){
        String url = "jdbc:sqlite:Clinic_database.db";
        changePage(event, "AppointmentRequestPage.fxml", false);
    }
    @FXML
    private void changepassword(ActionEvent event) {
        changePage(event, "ChangePasswordPage.fxml", false);
    }

    @FXML
    private void logout(ActionEvent event){
        Plogout(event);
    }
}
