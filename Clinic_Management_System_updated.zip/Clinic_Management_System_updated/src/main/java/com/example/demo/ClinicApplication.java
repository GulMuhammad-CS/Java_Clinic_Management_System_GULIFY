package com.example.demo;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.Statement;
import java.time.LocalDate;

import static com.example.demo.patients.setcurrentpatientID;

//classes mainly used for the variety of tables shown throughout the program
class doctors{
    public static int currentDoctorID=0;
    private int id;
    private String email;
    private String password;
    private String name;
    private int specialtyId;
    private String status;
    public doctors(int id, String name, String email, int specialtyId, String status) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.specialtyId=specialtyId;
        this.status=status;
    }
    public int getId(){return id;}
    public static int getCurrentDoctorID(){return currentDoctorID;}
    public static void setCurrentDoctorID(int id){currentDoctorID=id;}
    public String getName(){return name;}
    public String getEmail(){return email;}
    public Integer getSpecialtyId() {return specialtyId;}
    public String getStatus(){return status;}
    public void setSpecialtyID(int specialtyId){
        this.specialtyId=specialtyId;
    }
    public void setStatus(String Status){
        this.status=Status;
    }

}

class prescriptions{
    private int prescriptionID;
    private int doctorID;
    private int patientID;
    private LocalDate date;
    private int medicineID;
    public prescriptions(int prescriptionID, int patientID, LocalDate date, int medicineID) {
        this.prescriptionID = prescriptionID;
        this.patientID = patientID;
        this.date = date;
        this.medicineID = medicineID;
    }
    public int getPrescriptionID(){return prescriptionID;}
    public int getDoctorID(){return doctorID;}
    public int getPatientID(){return patientID;}
    public LocalDate getDate(){return date;}
    public int getMedicineID(){return medicineID;}
    public void setPrescriptionID(int prescriptionID){
        this.prescriptionID = prescriptionID;
    }
    public void setDoctorID(int doctorID){
        this.doctorID = doctorID;
    }
    public void setPatientID(int patientID){
        this.patientID = patientID;
    }
    public void setDate(LocalDate date){
        this.date = date;
    }
    public void setMedicineID(int medicineID){
        this.medicineID = medicineID;
    }
}

//logout method which resets variables for current user or doctor, and shows chooseuserpage
class logout{
    public static void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    public static void Plogout(ActionEvent event){
        changepage.changePage(event, "chooseUserpage.fxml", false);
        setcurrentpatientID(0);
        doctors.setCurrentDoctorID(0);
    }
}

//function to change page to reduce code repetition
class changepage{
    public static void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    public static void changePage(ActionEvent event, String pagename, boolean setResizeable){
        try {
            FXMLLoader loader = new FXMLLoader(changepage.class.getResource(pagename));
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(scene);
            stage.setResizable(setResizeable);
            stage.show();
        } catch (Exception e) {
            showErrorAlert("Failed to load page: " + e.getMessage());
            e.printStackTrace();
            return;
        }

    }
}

class appointments{
    private int appointmentID;
    private int APatientID;
    private LocalDate appointmentDate;
    private String appointmentTime;
    public appointments(int appointmentID, int APatientID, LocalDate appointmentDate, String appointmentTime) {
        this.appointmentID = appointmentID;
        this.APatientID = APatientID;
        this.appointmentDate = appointmentDate;
        this.appointmentTime = appointmentTime;
    }
    public int getAppointmentID(){return appointmentID;}
    public int getAPatientID(){return APatientID;}
    public LocalDate getAppointmentDate(){return appointmentDate;}
    public String getAppointmentTime(){return appointmentTime;}
    public void setAppointmentID(int appointmentID){
        this.appointmentID=appointmentID;
    }
    public void setAPatientID(int APatientID){
        this.APatientID=APatientID;
    }
    public void setAppointmentDate(LocalDate appointmentDate){
        this.appointmentDate=appointmentDate;
    }
    public void setAppointmentTime(String appointmentTime){
        this.appointmentTime=appointmentTime;
    }

}
class patients{
    private int id;
    //variable to keep track of current patient user (if user is a patient), getter and setter methods used
    //throughout program as well
    public static int currentpatientID;
    private String email;
    private String password;
    private String name;
    private int age;
    private String gender;
    private LocalDate DOB;
    private int doctorId;
    public patients(int id, String email, String name, int age, String gender, LocalDate DOB, int doctorId) {
        this.id = id;
        this.email = email;
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.DOB = DOB;
        this.doctorId = doctorId;
    }
    public int getId(){return id;}
    public String getEmail(){return email;}
    public String getPassword(){return password;}
    public String getName(){return name;}
    public int getAge(){return age;}
    public String getGender(){return gender;}
    public LocalDate getDOB(){return DOB;}
    public int getDoctorId(){return doctorId;}
    public static int getcurrentpatientID(){return currentpatientID;}
    public static void setcurrentpatientID(int ID){
        currentpatientID=ID;
    }
    public void setDoctorID(int doctorId){}
    public void setEmail(String email){this.email=email;}
    public void setPassword(String password){this.password=password;}
    public void setName(String name){this.name=name;}
    public void setAge(int age){this.age=age;}
    public void setGender(String gender){this.gender=gender;}
    public void setDOB(LocalDate DOB){this.DOB=DOB;}
    public void setDoctorId(int doctorId){this.doctorId=doctorId;}
}
//similar to appointments class, but changed to show details about doctor like their name instead of ID
class patientAppointments{
    private int appointmentID;
    private String DoctorName;
    private LocalDate appointmentDate;
    private String appointmentTime;
    public patientAppointments(int appointmentID, String DoctorName, LocalDate appointmentDate, String appointmentTime) {
        this.appointmentID = appointmentID;
        this.DoctorName = DoctorName;
        this.appointmentDate = appointmentDate;
        this.appointmentTime = appointmentTime;
    }
    public int getAppointmentID(){return appointmentID;}
    public String getDoctorName(){return DoctorName;}
    public LocalDate getAppointmentDate(){return appointmentDate;}
    public String getAppointmentTime(){return appointmentTime;}
}
//similar to normal prescriptions class, but altered to show doctor name and medicine details as well to patient
class patientPrescriptions{
    private int prescriptionID;
    private String doctorName;
    private String MedicineName;
    private String MedicineSalt;
    private String MedicineDosageForm;
    private String MedicineDosageStrength;
    private LocalDate PrescriptionDate;
    public patientPrescriptions(int prescriptionID, String doctorName, String MedicineName, String MedicineSalt, String MedicineDosageForm,String MedicineDosageStrength, LocalDate PrescriptionDate){
        this.prescriptionID = prescriptionID;
        this.doctorName = doctorName;
        this.MedicineName = MedicineName;
        this.MedicineSalt = MedicineSalt;
        this.MedicineDosageForm = MedicineDosageForm;
        this.MedicineDosageStrength = MedicineDosageStrength;
        this.PrescriptionDate = PrescriptionDate;

    }
    public int getPrescriptionID(){return prescriptionID;}
    public String getDoctorName(){return doctorName;}
    public String getMedicineName(){return MedicineName;}
    public String getMedicineSalt(){return MedicineSalt;}
    public LocalDate getPrescriptionDate(){return PrescriptionDate;}
    public String getMedicineDosageForm(){return MedicineDosageForm;}
    public String getMedicineDosageStrength(){return MedicineDosageStrength;}
}
class specialties{
    private int SpecialtyId;
    private String Specialty;
    public specialties(int SpecialtyID, String Specialty){
        this.SpecialtyId=SpecialtyID;
        this.Specialty=Specialty;
    }
    public int getSpecialtyId(){
        return SpecialtyId;
    }
    public String getSpecialty(){return Specialty;}
    public void setSpecialtyId(int ID){
        this.SpecialtyId=ID;
    }
    public void setSpecialtyId(String Specialty){
        this.Specialty=Specialty;
    }
}

class medicines{
    private int MedicineID;
    private String MedicineName;
    private String MedicineSalt;
    private String MedicineDosageForm;
    private String MedicineDosageStrength;
    public medicines(int MedicineID, String MedicineName, String MedicineSalt, String MedicineDosageForm, String MedicineDosageStrength) {
        this.MedicineID = MedicineID;
        this.MedicineName = MedicineName;
        this.MedicineSalt = MedicineSalt;
        this.MedicineDosageForm = MedicineDosageForm;
        this.MedicineDosageStrength = MedicineDosageStrength;

    }
    public int getMedicineID(){
        return MedicineID;
    }
    public String getMedicineName(){
        return MedicineName;
    }
    public String getMedicineSalt(){
        return MedicineSalt;
    }
    public String getMedicineDosageForm(){
        return MedicineDosageForm;
    }
    public String getMedicineDosageStrength(){
        return MedicineDosageStrength;
    }
    public void setMedicineID(int MedicineID){
        this.MedicineID=MedicineID;
    }
    public void setMedicineName(String MedicineName){
        this.MedicineName=MedicineName;
    }
    public void setMedicineSalt(String MedicineSalt){
        this.MedicineSalt=MedicineSalt;
    }
    public void setMedicineDosageForm(String MedicineDosageForm){
        this.MedicineDosageForm=MedicineDosageForm;
    }
    public void setMedicineDosageStrength(String MedicineDosageStrength){
        this.MedicineDosageStrength=MedicineDosageStrength;
    }
}


public class ClinicApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        createdatabase();
        FXMLLoader fxmlLoader = new FXMLLoader(ClinicApplication.class.getResource("chooseUserpage.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setScene(scene);
        stage.setResizable(false);
        stage.setTitle("GULIFY CLINIC MANAGEMENT SYSTEM");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();
    }
    //create database and tables if it doesn't already exist
    public static void createdatabase() {

        String url = "jdbc:sqlite:Clinic_database.db";


        String createAdminsTable = "CREATE TABLE IF NOT EXISTS Admins ("
                + "AdminID INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "AdminName TEXT NOT NULL, "
                + "AdminEmail TEXT NOT NULL, "
                + "AdminPassword TEXT NOT NULL, "
                + "AccessLevel INTEGER NOT NULL"
                + ");";

        String createSpecialtiesTable = "CREATE TABLE IF NOT EXISTS Specialties ("
                + "SpecialtyID INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "Specialty TEXT NOT NULL"
                + ");";

        String createDoctorsTable = "CREATE TABLE IF NOT EXISTS Doctors ("
                + "DoctorID INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "DoctorName TEXT NOT NULL, "
                + "DoctorEmail TEXT NOT NULL, "
                + "DoctorPassword TEXT NOT NULL, "
                + "SpecialtyID INTEGER NOT NULL, "
                + "Status TEXT NOT NULL, "
                + "FOREIGN KEY(SpecialtyID) REFERENCES Specialties(SpecialtyID) ON DELETE CASCADE"
                + ");";

        String createMedicinesTable = "CREATE TABLE IF NOT EXISTS Medicines ("
                + "MedicineID INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "MedicineName TEXT NOT NULL, "
                + "MedicineSalt TEXT NOT NULL, "
                + "MedicineDosageForm TEXT NOT NULL, "
                + "MedicineDosageStrength TEXT NOT NULL "
                + ");";


        String createPatientsTable = "CREATE TABLE IF NOT EXISTS Patients ("
                + "PatientID INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "PatientEmail TEXT NOT NULL, "
                + "Password TEXT NOT NULL, "
                + "DoctorID INTEGER NOT NULL, "
                + "PatientName TEXT NOT NULL, "
                + "PatientAge INTEGER NOT NULL, "
                + "Gender TEXT NOT NULL, "
                + "DateOfBirth DATE NOT NULL, "
                + "FOREIGN KEY (DoctorID) REFERENCES Doctors(DoctorID) ON DELETE CASCADE"
                + ");";

        String createAppointmentsTable = "CREATE TABLE IF NOT EXISTS Appointments ("
                + "AppointmentID INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "DoctorID INTEGER NOT NULL, "
                + "PatientID INTEGER NOT NULL, "
                + "AppointmentDate DATE NOT NULL, "
                + "AppointmentTime TEXT NOT NULL, "
                + "AppointmentStatus TEXT NOT NULL, "
                + "FOREIGN KEY (DoctorID) REFERENCES Doctors(DoctorID) ON DELETE CASCADE, "
                + "FOREIGN KEY (PatientID) REFERENCES Patients(PatientID) ON DELETE CASCADE"
                + ");";
        String createPrescriptionsTable = "CREATE TABLE IF NOT EXISTS Prescriptions ("
                + "PrescriptionID INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "DoctorID INTEGER NOT NULL, "
                + "PatientID INTEGER NOT NULL, "
                + "PrescriptionDate DATE NOT NULL, "
                + "MedicineID INTEGER NOT NULL, "
                + "FOREIGN KEY (PatientID) REFERENCES Patients(PatientID) ON DELETE CASCADE,"
                + "FOREIGN KEY (DoctorID) REFERENCES Doctors(DoctorID) ON DELETE CASCADE,"
                + "FOREIGN KEY (MedicineID) REFERENCES Medicines(MedicineID) ON DELETE CASCADE"
                + ");";
        String addTestDataQuery="";

        String addSuperAdmin="INSERT INTO Admins (AdminName, AdminEmail, AdminPassword, AccessLevel) SELECT 'SystemAdmin', 'SystemAdmin@clincare.com', 'SystemSuperAdmin', '1' WHERE NOT EXISTS(SELECT 1 FROM Admins);";
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement()) {
            stmt.execute("PRAGMA foreign_keys = ON;");
            stmt.execute(createAdminsTable);
            stmt.execute(createSpecialtiesTable);
            stmt.execute(createDoctorsTable);
            stmt.execute(createMedicinesTable);
            stmt.execute(createPatientsTable);
            stmt.execute(createAppointmentsTable);
            stmt.execute(createPrescriptionsTable);
            stmt.execute(addSuperAdmin);
        } catch (Exception e) {
            e.printStackTrace();

        }
    }

    public static void main(String[] args) {
        launch();
    }
}