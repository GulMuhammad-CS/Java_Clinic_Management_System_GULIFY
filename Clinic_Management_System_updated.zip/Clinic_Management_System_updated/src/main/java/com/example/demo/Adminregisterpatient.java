package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.*;
import java.time.LocalDate;
import java.time.Period;

import static com.example.demo.changepage.changePage;
import static com.example.demo.doctors.getCurrentDoctorID;

public class Adminregisterpatient {
    String url = "jdbc:sqlite:Clinic_database.db";
    public void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    public void showSuccessAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText("Patient Registration successful!");
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private TextField emailfield;
    @FXML
    private TextField namefield;
    @FXML
    private TextField passwordfield;
    @FXML
    private TextField confirmpasswordfield;
    @FXML
    private ChoiceBox<String> genderchoicebox;
    @FXML
    private TextField doctorIDfield;
    @FXML
    private DatePicker dateofbirthfield;
    @FXML
    public void initialize() {
        //populates choicelist with the gender options
        try {
            ObservableList<String> genderList = FXCollections.observableArrayList();
            genderList.add("Male");
            genderList.add("Female");
            genderList.add("Other");
            genderchoicebox.setItems(genderList);

        } catch (Exception e) {
            System.out.println(e.getMessage());
            showErrorAlert(e.getMessage());
            return;
        }
    }
    @FXML
    private void handlesubmit(ActionEvent event) {
        String email = emailfield.getText();
        String password = passwordfield.getText();
        String name = namefield.getText();
        String confirmpassword = confirmpasswordfield.getText();
        if(doctorIDfield.getText()==null || doctorIDfield.getText().trim().isEmpty()){
            showErrorAlert("Doctor ID is empty!");
            return;
        }
        int doctorID;
        //way of checking whether input is integer or not, if not it shows an error box
        try{
            doctorID=Integer.parseInt(doctorIDfield.getText());
        }
        catch(NumberFormatException e){
            showErrorAlert("Doctor ID is invalid! Please enter a valid Integer!");
            return;
        }

        boolean doctorExists=false;
        try(Connection conn=DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT DoctorID FROM Doctors ;");){
            while(rs.next()){
                if(doctorID==rs.getInt("DoctorID")){
                    doctorExists = true;
                    break;
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
            return;
        }
        if(!doctorExists){
            showErrorAlert("Doctor does not exist!");
            return;
        }
        //makes sure a choice is made for the choice boc
        if(genderchoicebox.getValue()==null){
            showErrorAlert("Please choose the suitable gender");
            return;
        }
        String gender=genderchoicebox.getValue();
        //makes sure date picker isn't left empty
        if(dateofbirthfield.getValue()==null){
            showErrorAlert("Date of Birth selection is empty!");
            return;
        }
        LocalDate dateofbirth = dateofbirthfield.getValue();
        if(email.isEmpty() || password.isEmpty() || name.isEmpty() || confirmpassword.isEmpty()){
            showErrorAlert("Please fill all the fields");
            return;
        }
        if(password.length()<7){
            showErrorAlert("Password must be at least 7 characters");
            return;
        }

        if(!password.equals(confirmpassword)){
            showErrorAlert("Passwords do not match");
            return;
        }
        if(!email.contains("@")){
            showErrorAlert("Please enter a valid email address");
            return;
        }
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT PatientEmail FROM Patients WHERE DoctorID=" + doctorID)) {
            //checks if patient already exists for the specified doctor, as patients can be regsitered under multiple doctors
            while(rs.next()) {
                if(email.equals(rs.getString("PatientEmail"))) {
                    showErrorAlert("Email already exists");
                    return;
                }
            }
        } catch (Exception e) {
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;
        }
        //makes sure DOB is valid
        if(dateofbirth.isAfter(LocalDate.now())){
            showErrorAlert("Date of birth can't be in the future! Please enter a valid date");
            return;
        }
        //automatically calculates age based on DOB and current date
        int patientage= Period.between(dateofbirth, LocalDate.now()).getYears();
        try (Connection conn = DriverManager.getConnection(url);){
            //uses prepared statement to prepare and insert data into database, prepared statements
            //also help to reduce risk of SQL injection attacks
            String sql = "INSERT INTO Patients (PatientName, PatientEmail, Password, DoctorID, PatientAge, Gender, DateOfBirth) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)";


            PreparedStatement pstmt = conn.prepareStatement(sql);


            pstmt.setString(1, name);
            pstmt.setString(2, email);
            pstmt.setString(3, password);
            pstmt.setInt(4, doctorID);
            pstmt.setInt(5, patientage);
            pstmt.setString(6, gender);
            pstmt.setDate(7, java.sql.Date.valueOf(dateofbirth));

            //executes insertion query and then clearing all fields
            pstmt.executeUpdate();
            emailfield.clear();
            passwordfield.clear();
            namefield.clear();
            confirmpasswordfield.clear();
            genderchoicebox.setValue(null);
            dateofbirthfield.setValue(null);
            doctorIDfield.clear();
            showSuccessAlert("Patient: "+name+" has successfully been registered!");
        } catch (Exception e) {
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;

        }
        //navigating back to profile page after registration
        changePage(event, "AdminProfilePage.fxml", true);
    }
    @FXML
    private Button cancelbutton;
    @FXML
    private void cancel(ActionEvent event) {
        changePage(event, "AdminProfilePage.fxml", false);
    }
}
