package com.example.demo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import java.sql.*;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;


import static com.example.demo.changepage.changePage;
import static com.example.demo.doctors.setCurrentDoctorID;

public class DoctorLogin {
    String url = "jdbc:sqlite:Clinic_database.db";
    public void showErrorAlert(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private TextField emailfield;
    @FXML
    private PasswordField passwordfield;
    @FXML
    private void handleSubmit(ActionEvent actionEvent) {
        String email = emailfield.getText();
        String password = passwordfield.getText();
        int count_checks = 0;
        if (email.isEmpty() || password.isEmpty()) {
            showErrorAlert("Please fill all the fields");
        }
        else{
            count_checks++;
        }
        String emailcheckquery="SELECT DoctorEmail FROM Doctors";
        boolean emailexists=false;
        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt=conn.createStatement();
            ResultSet rs = stmt.executeQuery(emailcheckquery)){
            while(rs.next()){
                if(email.equals(rs.getString("DoctorEmail"))){
                    emailexists=true;
                    break;
                }

            }
        }
        catch(Exception e){
            showErrorAlert("Something went wrong");
        }
        if(!emailexists){
            showErrorAlert("This email does not have an account with us. Please enter a valid email");
        }
        else{
            count_checks++;
        }
        String logincheckquery = "SELECT DoctorID, DoctorPassword FROM Doctors WHERE DoctorEmail = ?";
        boolean loginsuccessful = false;

        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement pstmt = conn.prepareStatement(logincheckquery)) {
            pstmt.setString(1, email);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    if (password.equals(rs.getString("DoctorPassword"))) {
                        loginsuccessful = true;
                        setCurrentDoctorID(rs.getInt("DoctorID"));
                        break;
                    }
                }
            }
        } catch (Exception e) {
            showErrorAlert("Something went wrong: " + e.getMessage());
        }
        if(loginsuccessful){
            changePage(actionEvent, "doctorProfilePage.fxml", true);
        }
        else{
            showErrorAlert("Password does not match! Please enter a valid password");
            return;
        }

    }
    @FXML
    private void cancel(ActionEvent event){
        changePage(event, "chooseUserpage.fxml", false);
    }
}

