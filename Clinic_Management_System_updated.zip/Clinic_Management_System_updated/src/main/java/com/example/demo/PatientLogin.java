package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.sql.*;

import static com.example.demo.changepage.changePage;
import static com.example.demo.doctors.setCurrentDoctorID;
import static com.example.demo.patients.setcurrentpatientID;

public class PatientLogin {
    String url = "jdbc:sqlite:Clinic_database.db";
    public void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);  // Use AlertType.ERROR for error dialogs
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();  // Display the alert and wait for user action
    }
    @FXML
    private TextField emailfield;
    @FXML
    private PasswordField passwordfield;
    @FXML
    private void handleSubmit(ActionEvent actionEvent) {
        System.out.println("button clicked!");
        String email = emailfield.getText();
        String password = passwordfield.getText();
        int count_checks = 0;
        if (email.isEmpty() || password.isEmpty()) {
            showErrorAlert("Please fill all the fields");
            return;
        }
        else{
            count_checks++;
        }
        String emailcheckquery="SELECT PatientEmail FROM Patients";
        boolean emailexists=false;
        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt=conn.createStatement();
            ResultSet rs = stmt.executeQuery(emailcheckquery)){
            while(rs.next()){
                if(email.equals(rs.getString("PatientEmail"))){
                    emailexists=true;
                    break;
                }

            }
        }
        catch(Exception e){
            showErrorAlert("Something went wrong");
            e.printStackTrace();
            return;
        }
        if(!emailexists){
            showErrorAlert("This email does not have an account with us. Please enter a valid email");
            return;
        }
        else{
            count_checks++;
        }
        System.out.println("secondary checks done");
        String logincheckquery = "SELECT PatientID, Password FROM Patients WHERE PatientEmail = ?";
        boolean loginsuccessful = false;

        try (Connection conn = DriverManager.getConnection(url);
             PreparedStatement pstmt = conn.prepareStatement(logincheckquery)) {
            pstmt.setString(1, email);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    if (password.equals(rs.getString("Password"))) {

                        loginsuccessful = true;
                        setcurrentpatientID(rs.getInt("PatientID"));
                        break;
                    }
                }
            }
        } catch (Exception e) {
            showErrorAlert("Something went wrong: " + e.getMessage());
        }
        if(loginsuccessful){

            changePage(actionEvent, "patientProfilepage.fxml", true);
        }
        else{
            showErrorAlert("Incorrect password! Please enter a valid password");
            return;
        }

    }
    @FXML
    private void cancellogin(ActionEvent actionEvent) {
        changePage(actionEvent, "chooseUserpage.fxml", false);
        }
    }



