package com.example.demo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import java.sql.*;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

import static com.example.demo.changepage.changePage;

public class adminLogin {
    String url = "jdbc:sqlite:Clinic_database.db";
    public void showErrorAlert(String message) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private TextField emailfield;
    @FXML
    private PasswordField passwordfield;
    @FXML
    private void handleSubmit(ActionEvent actionEvent) {
        //storing user inputs in variables
        String email = emailfield.getText();
        String password = passwordfield.getText();
        //checks to make sure all fields were entered
        if (email.isEmpty() || password.isEmpty()) {
            showErrorAlert("Please fill all the fields");
            return;
        }
        //checks to make sure email exists in database
        String emailcheckquery="SELECT AdminEmail FROM Admins";
        boolean emailexists=false;
        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt=conn.createStatement();
            ResultSet rs = stmt.executeQuery(emailcheckquery)){
            while(rs.next()){
                if(email.equals(rs.getString("AdminEmail"))){
                    emailexists=true;
                    break;
                }

            }
        }
        catch(Exception e){
            showErrorAlert("Something went wrong:"+e.getMessage());
            return;
        }
        //displays error message in case it doesnt exist
        if(!emailexists){
            showErrorAlert("This email does not have an account with us. Please enter a valid email or register");
            return;
        }
        //query to check and verify login credentials
        String logincheckquery = "SELECT AdminPassword, AccessLevel FROM Admins WHERE AdminEmail = ?";
        //variables to determine chronology of events, depending on whether the details entered
        //are that of the super admin or not
        boolean loginsuccessful = false;
        boolean isSuperUser = false;

        try (Connection conn = DriverManager.getConnection(url);
            PreparedStatement pstmt = conn.prepareStatement(logincheckquery)) {
            pstmt.setString(1, email);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    if (password.equals(rs.getString("AdminPassword"))) {
                        loginsuccessful = true;
                        if(rs.getInt("AccessLevel") == 1){
                            isSuperUser = true;
                        }
                        break;
                    }
                }
            }
        } catch (Exception e) {
            showErrorAlert("Something went wrong: " + e.getMessage());
            return;
        }
        //incorrect password error
        if(!loginsuccessful){
            showErrorAlert("Incorrect password! Please enter a valid password");
            return;
        }
        //proceeds as normal login
        if(loginsuccessful && !isSuperUser){
            changePage(actionEvent, "AdminProfilePage.fxml", true);

        }
        //interprets as first time login through superuser credentials, directs admin to register
        if(loginsuccessful && isSuperUser){
            changePage(actionEvent, "adminregistrationpage.fxml", false);
        }

    }
    @FXML
    private void cancel(ActionEvent actionEvent) {
        changePage(actionEvent, "chooseUserpage.fxml", false);
    }
}
