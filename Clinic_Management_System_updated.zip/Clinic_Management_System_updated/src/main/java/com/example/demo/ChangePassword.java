package com.example.demo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import static com.example.demo.changepage.changePage;

import java.sql.*;

import static com.example.demo.patients.getcurrentpatientID;

public class ChangePassword {
    String url = "jdbc:sqlite:Clinic_database.db";
    public void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    public void showSuccessAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText("Password Change successful!");
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private TextField currentpasswordfield;
    @FXML
    private TextField newpasswordfield;
    @FXML
    private TextField confirmnewpasswordfield;
    @FXML
    private void handleSubmit(ActionEvent event) {
        String currentpassword=currentpasswordfield.getText();
        String newpassword=newpasswordfield.getText();
        String confirmnewpassword=confirmnewpasswordfield.getText();
        if(currentpassword.isEmpty() || newpassword.isEmpty() || confirmnewpassword.isEmpty()){
            showErrorAlert("Please fill all fields!");
            return;
        }
        //ensures current password entered is valid
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();
             ResultSet resultSet = stmt.executeQuery("SELECT PatientID, Password FROM Patients WHERE PatientID="+getcurrentpatientID()+";")) {

            while(resultSet.next()) {
                if(!currentpassword.equals(resultSet.getString("Password"))) {
                    showErrorAlert("Current password is wrong!");
                    return;
                }
            }

        } catch (Exception e) {
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;}
        //basic checks, makes sure new passwords are valid
        if(currentpassword.equals(newpassword)){
            showErrorAlert("New password can't be the same as the old password!");
            return;
        }
        if(!newpassword.equals(confirmnewpassword)){
            showErrorAlert("New passwords do not match!");
            return;
        }
        if(newpassword.length()<7){
            showErrorAlert("New password must be at least 7 characters!");
            return;
        }
        try(Connection connection=DriverManager.getConnection(url);){
            String sql = "UPDATE Patients SET Password=? WHERE PatientID=?";

            PreparedStatement pstmt = connection.prepareStatement(sql);
            pstmt.setString(1, newpassword);
            pstmt.setInt(2, getcurrentpatientID());
            pstmt.executeUpdate();
        }
        catch(Exception e){
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;
        }
        changePage(event, "patientProfilepage.fxml", true);

    }
    @FXML
    private void cancel(ActionEvent event) {
        changePage(event, "patientProfilepage.fxml", true);
    }
}
