package com.example.demo;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

import static com.example.demo.changepage.changePage;
import static com.example.demo.doctors.getCurrentDoctorID;
import static com.example.demo.doctors.setCurrentDoctorID;
import static com.example.demo.logout.Plogout;

public class Doctorprofile {
    public void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    public void showSuccessAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText("Success!");
        alert.setContentText(message);
        alert.showAndWait();
    }
    //loading labels so that they can be updated to show doctor information
    @FXML
    private Label namelabel;
    @FXML
    private Label emaillabel;
    @FXML
    private Label statuslabel;
    String name = "";
    String email ="";
    String status="";
    @FXML
    public void loadLabels(){
        String url="jdbc:sqlite:Clinic_database.db";
        //fetching relevant data from database
        String query = "SELECT * FROM Doctors WHERE DoctorID="+getCurrentDoctorID();
        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query)){
            while (rs.next()){
                name =rs.getString("DoctorName");
                email =rs.getString("DoctorEmail");
                status =rs.getString("Status");

            }
            //updating labels to show relevant information
            namelabel.setText("Name: "+name);
            emaillabel.setText("Email: "+email);
            statuslabel.setText("Status: "+status);

        }
        catch (SQLException e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
        }

    }

    @FXML
    private Button removepatientsbutton;
    @FXML
    private Button cancelappointmentbutton;
    @FXML
    private Button removepresbutton;
    //appointments part
    //declaring table view as well as its columns, and which class the objects in the table will be a part of
    @FXML
    private TableView<appointments> appointmentTableView;
    @FXML
    private TableColumn<appointments, Integer> appointmentID;
    @FXML
    private TableColumn<appointments, Integer> APatientID;
    @FXML
    private TableColumn<appointments, LocalDate> appointmentDate;
    @FXML
    private TableColumn<appointments, String> appointmentTime;
    //observable array list to store instances of the object classes before they are added to the tables
    @FXML
    private ObservableList<appointments> appointmentslist= FXCollections.observableArrayList();
    @FXML
    public void initializeappointmentTableView() {
        //connection each tablecolumn with the relevant getter method for the class objects
        //for integer values such as ID, it converts the integer value into a SimpleIntegerProperty
        //and wraps it as an object for the table cell
        //similar concept for strings and dates although they dont have to be wrapped as objects,
        //as they are inherently treated as such
        appointmentID.setCellValueFactory(cellData->
                new SimpleIntegerProperty(cellData.getValue().getAppointmentID()).asObject());
        APatientID.setCellValueFactory(cellData->
                new SimpleIntegerProperty(cellData.getValue().getAPatientID()).asObject());
        appointmentDate.setCellValueFactory(cellData->
                new SimpleObjectProperty<>(cellData.getValue().getAppointmentDate()));
        appointmentTime.setCellValueFactory(cellData->
                new SimpleStringProperty(cellData.getValue().getAppointmentTime()));
    }
    @FXML
    private void loadappointmentTableView() {
        String url="jdbc:sqlite:Clinic_database.db";
        String query = "SELECT * FROM Appointments WHERE AppointmentStatus='upcoming' AND DoctorID="+getCurrentDoctorID();

        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query)){
            while (rs.next()){
                //looping through relevant records in database to store each record as an instance of the respective class
                //to be added to the observablearraylist which is then added into the table
                Date sqlDate = rs.getDate("AppointmentDate");
                LocalDate localDate = null;
                if (sqlDate != null) {
                    localDate = sqlDate.toLocalDate(); // This converts sql.Date to LocalDate
                }
                appointmentslist.add(new appointments(
                        rs.getInt("AppointmentID"),
                        rs.getInt("PatientID"),
                        localDate,
                        rs.getString("AppointmentTime")

                ));

            }

        }
        catch (SQLException e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
            return;
        }
        //updates status for any appointment for which the date has already passed to be completed
        try(Connection conn=DriverManager.getConnection(url);){
            String removeoldappointmentquery="UPDATE Appointments SET AppointmentStatus='completed' WHERE AppointmentStatus='upcoming' AND AppointmentDate<?";
            PreparedStatement pstmt=conn.prepareStatement(removeoldappointmentquery);
            pstmt.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
            pstmt.executeUpdate();
        }
        catch(SQLException e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
            return;
        }
        appointmentTableView.setItems(appointmentslist);
    }
    @FXML
    private void showappointmenttable(){
        //hides all other tables and remove buttons except for the appointment table and its remove button
        appointmentslist.clear();
        initializeappointmentTableView();
        loadappointmentTableView();
        patientTableView.setVisible(false);
        medicineTableView.setVisible(false);
        prescriptionTableView.setVisible(false);
        appointmentrequesttableview.setVisible(false);
        pastappointmenttableview.setVisible(false);
        appointmentTableView.setVisible(true);
    }
    //this process for tables is repeated in a similar fashion for all tables in this system
    //appointments part done
    //patients part
    @FXML
    private TableView<patients> patientTableView;
    @FXML
    private TableColumn<patients, Integer> PatientID;
    @FXML
    private TableColumn<patients, String> PatientName;
    @FXML
    private TableColumn<patients, String> PatientEmail;
    @FXML
    private TableColumn<patients, Integer> PatientAge;
    @FXML
    private TableColumn<patients, String> PatientGender;
    @FXML
    private TableColumn<patients, LocalDate> DateOfBirth;
    @FXML
    private TableColumn<patients, Integer> DoctorID;
    @FXML
    private ObservableList<patients> patientslist= FXCollections.observableArrayList();
    @FXML
    public void initializepatientTableView() {
        PatientID.setCellValueFactory(cellData->
                new SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        PatientName.setCellValueFactory(cellData->
                new SimpleStringProperty(cellData.getValue().getName()));
        PatientEmail.setCellValueFactory(cellData->
                new SimpleStringProperty(cellData.getValue().getEmail()));
        PatientGender.setCellValueFactory(cellData->
                new SimpleStringProperty(cellData.getValue().getGender()));
        PatientAge.setCellValueFactory(cellData->
                new SimpleIntegerProperty(cellData.getValue().getAge()).asObject());
        DateOfBirth.setCellValueFactory(cellData->
                new SimpleObjectProperty<>(cellData.getValue().getDOB()));
        DoctorID.setCellValueFactory(cellData->
                new SimpleIntegerProperty(cellData.getValue().getDoctorId()).asObject());
    }
    @FXML
    private void loadpatientTableView() {
        String url="jdbc:sqlite:Clinic_database.db";
        String query = "SELECT * FROM Patients WHERE DoctorID="+getCurrentDoctorID();
        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query)){
            while (rs.next()){
                Date sqlDate = rs.getDate("DateOfBirth");
                LocalDate localDate = null;
                if (sqlDate != null) {
                    localDate = sqlDate.toLocalDate();
                }
                patientslist.add(new patients(
                        rs.getInt("PatientID"),
                        rs.getString("PatientEmail"),
                        rs.getString("PatientName"),
                        rs.getInt("PatientAge"),
                        rs.getString("Gender"),
                        localDate,
                        rs.getInt("DoctorID")
                ));
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
        }
        patientTableView.setItems(patientslist);
    }
    @FXML
    private void showpatientstable(){
        patientslist.clear();
        initializepatientTableView();
        loadpatientTableView();
        medicineTableView.setVisible(false);
        prescriptionTableView.setVisible(false);
        appointmentTableView.setVisible(false);
        appointmentrequesttableview.setVisible(false);
        pastappointmenttableview.setVisible(false);
        patientTableView.setVisible(true);

    }
    //patients part done
    //medicines part
    //Medicines part

    @FXML
    private TableView<medicines> medicineTableView;
    @FXML
    private TableColumn<medicines, Integer> MedicineID;
    @FXML
    private TableColumn<medicines, String> MedicineName;
    @FXML
    private TableColumn<medicines, String> MedicineSalt;
    @FXML
    private TableColumn<medicines, String> MedicineDosageForm;
    @FXML
    private TableColumn<medicines, String> MedicineDosageStrength;
    @FXML
    private ObservableList<medicines> medicineList = FXCollections.observableArrayList();
    @FXML
    public void initializeMedicineTable(){
        MedicineID.setCellValueFactory(cellData ->
                new SimpleIntegerProperty(cellData.getValue().getMedicineID()).asObject());
        MedicineName.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getMedicineName()));
        MedicineSalt.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getMedicineSalt()));
        MedicineDosageForm.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getMedicineDosageForm()));
        MedicineDosageStrength.setCellValueFactory(cellData ->
                new SimpleStringProperty(cellData.getValue().getMedicineDosageStrength()));
    }
    @FXML
    private void loadMedicineTable(){
        String url="jdbc:sqlite:Clinic_database.db";
        String query = "SELECT * FROM Medicines";

        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query)){
            while (rs.next()){
                medicineList.add(new medicines(
                        rs.getInt("MedicineID"),
                        rs.getString("MedicineName"),
                        rs.getString("MedicineSalt"),
                        rs.getString("MedicineDosageForm"),
                        rs.getString("MedicineDosageStrength"))
                );
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
        }
        medicineTableView.setItems(medicineList);
    }
    @FXML
    private void showmedicineTable(){
        medicineList.clear();
        initializeMedicineTable();
        loadMedicineTable();
        patientTableView.setVisible(false);
        appointmentTableView.setVisible(false);
        prescriptionTableView.setVisible(false);
        appointmentrequesttableview.setVisible(false);
        pastappointmenttableview.setVisible(false);
        medicineTableView.setVisible(true);
    }
    //medicines part done
    //prescriptions part
    @FXML
    private TableView<prescriptions> prescriptionTableView;
    @FXML
    private TableColumn<prescriptions, Integer> PrescriptionID;
    @FXML
    private TableColumn<prescriptions, Integer> presPatientID;
    @FXML
    private TableColumn<prescriptions, LocalDate> PrescriptionDate;
    @FXML
    private TableColumn<prescriptions, Integer> presMedicineID;
    @FXML
    private ObservableList<prescriptions> prescriptionList = FXCollections.observableArrayList();
    @FXML
    public void initializePrescriptionTable(){
        PrescriptionID.setCellValueFactory(cellData ->
                new SimpleIntegerProperty(cellData.getValue().getPrescriptionID()).asObject());
        presPatientID.setCellValueFactory(cellData ->
                new SimpleIntegerProperty(cellData.getValue().getPatientID()).asObject());
        PrescriptionDate.setCellValueFactory(cellData ->
                new SimpleObjectProperty<>(cellData.getValue().getDate()));
        presMedicineID.setCellValueFactory(cellData ->
                new SimpleIntegerProperty(cellData.getValue().getMedicineID()).asObject());
    }
    @FXML
    private void loadPrescriptionTable(){
        String url="jdbc:sqlite:Clinic_database.db";
        String query = "SELECT * FROM Prescriptions WHERE DoctorID="+getCurrentDoctorID();

        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query)){

            while (rs.next()){
                Date sqlDate = rs.getDate("PrescriptionDate");
                LocalDate localDate = null;
                if (sqlDate != null) {
                    localDate = sqlDate.toLocalDate(); // This converts sql.Date to LocalDate
                }
                prescriptionList.add(new prescriptions(
                        rs.getInt("PrescriptionID"),
                        rs.getInt("PatientID"),
                        localDate,
                        rs.getInt("MedicineID")

                ));
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
        }

        prescriptionTableView.setItems(prescriptionList);
    }
    @FXML
    private void showprescriptionsTable(){
        prescriptionList.clear();
        initializePrescriptionTable();
        loadPrescriptionTable();
        patientTableView.setVisible(false);
        appointmentTableView.setVisible(false);
        medicineTableView.setVisible(false);
        appointmentrequesttableview.setVisible(false);
        pastappointmenttableview.setVisible(false);
        prescriptionTableView.setVisible(true);

    }
    //prescriptions part done
    //appointment requests part
    @FXML
    private TableView<appointments> appointmentrequesttableview;
    @FXML
    private TableColumn<appointments, Integer> RappointmentID;
    @FXML
    private TableColumn<appointments, Integer> RPatientID;
    @FXML
    private TableColumn<appointments, LocalDate> RAppointmentDate;
    @FXML
    private TableColumn<appointments, String> RAppointmentTime;
    @FXML
    private Button acceptrequestbutton;
    @FXML
    private Button declinerequestbutton;
    @FXML
    private ObservableList<appointments> appointmentsrequestlist= FXCollections.observableArrayList();
    @FXML
    public void initializeappointmentrequestTableView() {
        RappointmentID.setCellValueFactory(cellData->
                new SimpleIntegerProperty(cellData.getValue().getAppointmentID()).asObject());
        RPatientID.setCellValueFactory(cellData->
                new SimpleIntegerProperty(cellData.getValue().getAPatientID()).asObject());
        RAppointmentDate.setCellValueFactory(cellData->
                new SimpleObjectProperty<>(cellData.getValue().getAppointmentDate()));
        RAppointmentTime.setCellValueFactory(cellData->
                new SimpleStringProperty(cellData.getValue().getAppointmentTime()));
    }
    @FXML
    private void loadappointmentrequestTableView() {
        //similar to normal appointments table, but filters results now based on status
        String url="jdbc:sqlite:Clinic_database.db";
        String query = "SELECT * FROM Appointments WHERE AppointmentStatus='requested' AND DoctorID="+getCurrentDoctorID();

        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query)){
            while (rs.next()){
                Date sqlDate = rs.getDate("AppointmentDate");
                LocalDate localDate = null;
                if (sqlDate != null) {
                    localDate = sqlDate.toLocalDate(); // This converts sql.Date to LocalDate
                }
                appointmentsrequestlist.add(new appointments(
                        rs.getInt("AppointmentID"),
                        rs.getInt("PatientID"),
                        localDate,
                        rs.getString("AppointmentTime")

                ));

            }

        }
        catch (SQLException e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
            return;
        }
        try(Connection conn=DriverManager.getConnection(url);){
            String removeoldappointmentquery="UPDATE Appointments SET AppointmentStatus='completed' WHERE AppointmentStatus='upcoming' AND AppointmentDate<?";
            PreparedStatement pstmt=conn.prepareStatement(removeoldappointmentquery);
            pstmt.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
            pstmt.executeUpdate();
        }
        catch(SQLException e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
            return;
        }
        appointmentrequesttableview.setItems(appointmentsrequestlist);
    }
    @FXML
    private void showappointmentrequesttable(){
        appointmentsrequestlist.clear();
        initializeappointmentrequestTableView();
        loadappointmentrequestTableView();
        patientTableView.setVisible(false);
        medicineTableView.setVisible(false);
        prescriptionTableView.setVisible(false);
        appointmentTableView.setVisible(false);
        pastappointmenttableview.setVisible(false);
        appointmentrequesttableview.setVisible(true);

    }
    //appointment requests part done
    //cancelled/completed/rejected appointments part
    @FXML
    private TableView<appointments> pastappointmenttableview;
    @FXML
    private TableColumn<appointments, Integer> pastAppointmentID;
    @FXML
    private TableColumn<appointments, Integer> pastPatientID;
    @FXML
    private TableColumn<appointments, LocalDate> pastAppointmentDate;
    @FXML
    private TableColumn<appointments, String> pastAppointmentTime;
    @FXML
    private ObservableList<appointments> pastappointmentslist= FXCollections.observableArrayList();
    @FXML
    public void initializepastappointmentTableView() {
        pastAppointmentID.setCellValueFactory(cellData->
                new SimpleIntegerProperty(cellData.getValue().getAppointmentID()).asObject());
        pastPatientID.setCellValueFactory(cellData->
                new SimpleIntegerProperty(cellData.getValue().getAPatientID()).asObject());
        pastAppointmentDate.setCellValueFactory(cellData->
                new SimpleObjectProperty<>(cellData.getValue().getAppointmentDate()));
        pastAppointmentTime.setCellValueFactory(cellData->
                new SimpleStringProperty(cellData.getValue().getAppointmentTime()));
    }
    @FXML
    private void loadpastappointmentTableView() {
        //same as table above, just changes the status to filter by
        String url="jdbc:sqlite:Clinic_database.db";
        String query = "SELECT * FROM Appointments WHERE (AppointmentStatus='cancelled' OR AppointmentStatus='completed') AND DoctorID="+getCurrentDoctorID();

        try(Connection conn = DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(query)){
            while (rs.next()){
                Date sqlDate = rs.getDate("AppointmentDate");
                LocalDate localDate = null;
                if (sqlDate != null) {
                    localDate = sqlDate.toLocalDate(); // This converts sql.Date to LocalDate
                }
                pastappointmentslist.add(new appointments(
                        rs.getInt("AppointmentID"),
                        rs.getInt("PatientID"),
                        localDate,
                        rs.getString("AppointmentTime")

                ));

            }

        }
        catch (SQLException e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
            return;
        }
        try(Connection conn=DriverManager.getConnection(url);){
            String removeoldappointmentquery="UPDATE Appointments SET AppointmentStatus='completed' WHERE AppointmentStatus='upcoming' AND AppointmentDate<?";
            PreparedStatement pstmt=conn.prepareStatement(removeoldappointmentquery);
            pstmt.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
            pstmt.executeUpdate();
        }
        catch(SQLException e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
            return;
        }
        pastappointmenttableview.setItems(pastappointmentslist);
    }
    @FXML
    private void showpastappointmenttable(){
        pastappointmentslist.clear();
        initializepastappointmentTableView();
        loadpastappointmentTableView();
        patientTableView.setVisible(false);
        medicineTableView.setVisible(false);
        prescriptionTableView.setVisible(false);
        appointmentTableView.setVisible(false);
        appointmentrequesttableview.setVisible(false);
        pastappointmenttableview.setVisible(true);

    }
    //cancelled/completed/rejected appointments part done

    //initialize method is called automatically which automatically initializes the tables and binds the calculations
    //of its layout to whether or not it is visible, ensuring that each table appears properly instead of crammed
    @FXML
    public void initialize() {
        // Set up all table columns first
        initializepatientTableView();
        initializeMedicineTable();
        initializePrescriptionTable();
        initializeappointmentTableView();
        initializeappointmentrequestTableView();
        initializepastappointmentTableView();
        loadLabels();
        patientTableView.managedProperty().bind(patientTableView.visibleProperty());
        medicineTableView.managedProperty().bind(medicineTableView.visibleProperty());
        appointmentTableView.managedProperty().bind(appointmentTableView.visibleProperty());
        prescriptionTableView.managedProperty().bind(prescriptionTableView.visibleProperty());
        appointmentrequesttableview.managedProperty().bind(appointmentrequesttableview.visibleProperty());
        pastappointmenttableview.managedProperty().bind(pastappointmenttableview.visibleProperty());
        // Make the doctors table visible by default
        patientTableView.setVisible(false);
        medicineTableView.setVisible(false);
        appointmentTableView.setVisible(false);
        prescriptionTableView.setVisible(false);
        appointmentrequesttableview.setVisible(false);
        pastappointmenttableview.setVisible(false);

        // Load the data for the visible table
        loadpatientTableView();
    }
    //toggle status
    @FXML
    private void togglestatus(){
        //changes status in database depending on current status and updates label accordingly
        String url = "jdbc:sqlite:Clinic_database.db";
        String togglequeryavailable="UPDATE Doctors SET Status='available' WHERE DoctorID='"+getCurrentDoctorID()+"'";
        String togglequerynotavailable="UPDATE Doctors SET Status='not available' WHERE DoctorID='"+getCurrentDoctorID()+"'";
        String getstatusquery="SELECT Status FROM Doctors WHERE DoctorID='"+getCurrentDoctorID()+"'";
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement()) {
            ResultSet rs = stmt.executeQuery(getstatusquery);
            while(rs.next()){
                String status = rs.getString("Status");
                if(status.equals("available")){
                    stmt.executeUpdate(togglequerynotavailable);
                }
                if(status.equals("not available")){
                    stmt.executeUpdate(togglequeryavailable);
                }
            }
        }
        catch (SQLException e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
        }
        loadLabels();
    }
    //goes to various addition pages
    @FXML
    private void addAppointment(ActionEvent event){
        changePage(event, "doctorsAddAppointmentPage.fxml", false);
    }
    @FXML
    private void addPatient(ActionEvent event){
        changePage(event, "patientregistrationpage.fxml", false);
    }
    @FXML
    private void addPrescription(ActionEvent event){
        changePage(event, "PrescriptionRegistrationPage.fxml", false);
    }

    @FXML
    public void deletepatient(ActionEvent event) {
        String url = "jdbc:sqlite:Clinic_database.db";
        patients selectedPatient = patientTableView.getSelectionModel().getSelectedItem();


        if (selectedPatient != null) {
            //sees which record was selected (if at all) and deletes it from database
            String query = "DELETE FROM Patients WHERE PatientID='" + selectedPatient.getId() + "'";
            try (Connection conn = DriverManager.getConnection(url);
                 Statement stmt = conn.createStatement()) {
                stmt.execute("PRAGMA foreign_keys = ON;");
                int rowsAffected = stmt.executeUpdate(query);
                if (rowsAffected > 0) {
                    patientslist.remove(selectedPatient);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                showErrorAlert(e.getMessage());
            }
        } else {
            showErrorAlert("Please select a patient to delete.");
        }
    }
    @FXML
    private void deleteprescription(ActionEvent event) {
        String url = "jdbc:sqlite:Clinic_database.db";
        prescriptions selectedprescription = prescriptionTableView.getSelectionModel().getSelectedItem();

        if (selectedprescription != null) {
            String query = "DELETE FROM Prescriptions WHERE PrescriptionID='" + selectedprescription.getPrescriptionID() + "'";
            try (Connection conn = DriverManager.getConnection(url);
                 Statement stmt = conn.createStatement()) {
                stmt.execute("PRAGMA foreign_keys = ON;");
                int rowsAffected = stmt.executeUpdate(query);
                if (rowsAffected > 0) {
                    prescriptionList.remove(selectedprescription);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                showErrorAlert(e.getMessage());
            }
        } else {
            showErrorAlert("Please select a prescription to delete.");
        }
    }
    @FXML
    private void cancelappointment(ActionEvent event) {
        String url = "jdbc:sqlite:Clinic_database.db";
        appointments selectedappointment = appointmentTableView.getSelectionModel().getSelectedItem();

        if (selectedappointment != null) {
            //instead of deleting completely, just changes status to keep track of appointment history
            String query = "UPDATE Appointments SET AppointmentStatus='cancelled' WHERE AppointmentID='" + selectedappointment.getAppointmentID() + "'";
            try (Connection conn = DriverManager.getConnection(url);
                 Statement stmt = conn.createStatement()) {
                stmt.execute("PRAGMA foreign_keys = ON;");
                int rowsAffected = stmt.executeUpdate(query);
                if (rowsAffected > 0) {
                    appointmentslist.remove(selectedappointment);
                }
            } catch (SQLException e) {
                e.printStackTrace();
                showErrorAlert(e.getMessage());
            }
        } else {
            showErrorAlert("Please select an appointment to cancel.");
        }
    }
    @FXML
    private void acceptappointment(){
        String url = "jdbc:sqlite:Clinic_database.db";
        appointments selectedappointment = appointmentrequesttableview.getSelectionModel().getSelectedItem();

        if (selectedappointment != null) {
            String query = "UPDATE Appointments SET AppointmentStatus='upcoming' WHERE AppointmentID='" + selectedappointment.getAppointmentID() + "'";
            try (Connection conn = DriverManager.getConnection(url);
                 Statement stmt = conn.createStatement()) {
                int rowsAffected = stmt.executeUpdate(query);
                if (rowsAffected > 0) {
                    showSuccessAlert("Appointment Accepted!");
                    appointmentsrequestlist.clear();
                    showappointmentrequesttable();
                }
            } catch (SQLException e) {
                e.printStackTrace();
                showErrorAlert(e.getMessage());
            }
        } else {
            showErrorAlert("Please select a request to accept.");
        }
    }
    @FXML
    private void rejectappointment(){
        String url = "jdbc:sqlite:Clinic_database.db";
        appointments selectedappointment = appointmentrequesttableview.getSelectionModel().getSelectedItem();

        if (selectedappointment != null) {
            String query = "UPDATE Appointments SET AppointmentStatus='cancelled' WHERE AppointmentID='" + selectedappointment.getAppointmentID() + "'";
            try (Connection conn = DriverManager.getConnection(url);
                 Statement stmt = conn.createStatement()) {
                int rowsAffected = stmt.executeUpdate(query);
                if (rowsAffected > 0) {
                    showSuccessAlert("Appointment Rejected.");
                    appointmentsrequestlist.clear();
                    showappointmentrequesttable();
                }
            } catch (SQLException e) {
                e.printStackTrace();
                showErrorAlert(e.getMessage());
            }
        } else {
            showErrorAlert("Please select a request to reject.");
        }
    }

// ABORTED EMAIL SENDING SYSTEM: attempted to implement system to send emails to users depending on whether their requests
//were accepted or rejected. aborted due to significantly slower performance which hampered usability
//    @FXML
//    private void acceptappointment() {
//        String url = "jdbc:sqlite:Clinic_database.db";
//        appointments selectedappointment = appointmentrequesttableview.getSelectionModel().getSelectedItem();
//
//        if (selectedappointment != null) {
////            String getpatientEmailQuery = "SELECT Patients.PatientEmail FROM Patients JOIN Appointments ON Appointments.PatientID=Patients.PatientID WHERE AppointmentID='" + selectedappointment.getAppointmentID() + "'";
////            String getDoctorNameQuery = "SELECT Doctors.DoctorName FROM Doctors JOIN Appointments ON Appointments.DoctorID=Doctors.DoctorID WHERE AppointmentID='" + selectedappointment.getAppointmentID() + "'";
//            String query = "UPDATE Appointments SET AppointmentStatus='upcoming' WHERE AppointmentID='" + selectedappointment.getAppointmentID() + "'";
//
//            Connection conn = null;
//            try {
//                conn = DriverManager.getConnection(url);
//                conn.setAutoCommit(false);
//                Statement patientEmailStmt = conn.createStatement();
//                ResultSet patientEmailRS = patientEmailStmt.executeQuery(getpatientEmailQuery);
//                String patientEmail = "";
//                if (patientEmailRS.next()) {
//                    patientEmail = patientEmailRS.getString(1);
//                } else {
//                    showErrorAlert("Patient email not found");
//                    return;
//                }
//                patientEmailRS.close();
//                patientEmailStmt.close();
//                Statement doctorNameStmt = conn.createStatement();
//                ResultSet doctorNameRS = doctorNameStmt.executeQuery(getDoctorNameQuery);
//                String doctorName = "";
//                if (doctorNameRS.next()) {
//                    doctorName = doctorNameRS.getString(1);
//                } else {
//                    showErrorAlert("Doctor name not found");
//                    return;
//                }
//                Statement updateStmt = conn.createStatement();
//                int rowsAffected = updateStmt.executeUpdate(query);
//                updateStmt.close();
//                appointmentsrequestlist.clear();
//                showappointmentrequesttable();
//
//                if (rowsAffected > 0) {
//                    conn.commit();
//                    emailsender sender = new emailsender();
//                    try {
//                        sender.sendEmail(patientEmail, "Appointment Request Accepted!",
//                                "Hey! \nWe are pleased to let you know that your appointment with " +
//                                        doctorName + " for " + selectedappointment.getAppointmentDate() +
//                                        " at " + selectedappointment.getAppointmentTime() +
//                                        " has been approved. \nPlease arrive at the clinic at least 10 minutes before your booking time. \nBest Regards,\nthe Clinic");
//
//                        showSuccessAlert("Appointment Accepted!");
//
//                    } catch(Exception e) {
//                        e.printStackTrace();
//                        showErrorAlert("Appointment accepted but email notification failed: " + e.getMessage());
//                    }
//                } else {
//
//                    conn.rollback();
//                    showErrorAlert("Failed to update appointment status");
//                }
//            } catch (SQLException e) {
//
//                if (conn != null) {
//                    try {
//                        conn.rollback();
//                    } catch (SQLException ex) {
//                        ex.printStackTrace();
//                    }
//                }
//                e.printStackTrace();
//                showErrorAlert(e.getMessage());
//            } finally {
//
//                if (conn != null) {
//                    try {
//                        conn.setAutoCommit(true);
//                        conn.close();
//                    } catch (SQLException e) {
//                        e.printStackTrace();
//                    }
//                }
//            }
//        } else {
//            showErrorAlert("Please select a request to accept.");
//        }
//    }
//
//    @FXML
//    private void rejectappointment(){
//        String url = "jdbc:sqlite:Clinic_database.db";
//        appointments selectedappointment = appointmentrequesttableview.getSelectionModel().getSelectedItem();
//
//        if (selectedappointment != null) {
//            String getpatientEmailQuery = "SELECT Patients.PatientEmail FROM Patients JOIN Appointments ON Appointments.PatientID=Patients.PatientID WHERE AppointmentID='" + selectedappointment.getAppointmentID() + "'";
//            String getDoctorNameQuery = "SELECT Doctors.DoctorName FROM Doctors JOIN Appointments ON Appointments.DoctorID=Doctors.DoctorID WHERE AppointmentID='" + selectedappointment.getAppointmentID() + "'";
//            String query = "UPDATE Appointments SET AppointmentStatus='cancelled' WHERE AppointmentID='" + selectedappointment.getAppointmentID() + "'";
//
//            Connection conn = null;
//            try {
//                conn = DriverManager.getConnection(url);
//                conn.setAutoCommit(false);
//                Statement patientEmailStmt = conn.createStatement();
//                ResultSet patientEmailRS = patientEmailStmt.executeQuery(getpatientEmailQuery);
//                String patientEmail = "";
//                if (patientEmailRS.next()) {
//                    patientEmail = patientEmailRS.getString(1);
//                } else {
//                    showErrorAlert("Patient email not found");
//                    return;
//                }
//                patientEmailRS.close();
//                patientEmailStmt.close();
//                Statement doctorNameStmt = conn.createStatement();
//                ResultSet doctorNameRS = doctorNameStmt.executeQuery(getDoctorNameQuery);
//                String doctorName = "";
//                if (doctorNameRS.next()) {
//                    doctorName = doctorNameRS.getString(1);
//                } else {
//                    showErrorAlert("Doctor name not found");
//                    return;
//                }
//                Statement updateStmt = conn.createStatement();
//                int rowsAffected = updateStmt.executeUpdate(query);
//                updateStmt.close();
//                doctorNameStmt.close();
//                doctorNameRS.close();
//                appointmentsrequestlist.clear();
//                showappointmentrequesttable();
//
//                if (rowsAffected > 0) {
//                    conn.commit();
//                    emailsender sender = new emailsender();
//                    try {
//                        sender.sendEmail(patientEmail, "Appointment Request Rejected",
//                                "Hey! \nUnfortunately, due to a busy schedule, " +
//                                        doctorName + " is not able to take your appointment for " + selectedappointment.getAppointmentDate() +
//                                        " at " + selectedappointment.getAppointmentTime() +
//                                        ". \nWe highly encourage you to request for another booking for the next best available time \nBest Regards,\nthe Clinic");
//
//                        showSuccessAlert("Appointment rejected");
//
//                    } catch(Exception e) {
//                        e.printStackTrace();
//                        showErrorAlert("Appointment rejected but email notification failed: " + e.getMessage());
//                    }
//                } else {
//
//                    conn.rollback();
//                    showErrorAlert("Failed to update appointment status");
//                }
//            } catch (SQLException e) {
//
//                if (conn != null) {
//                    try {
//                        conn.rollback();
//                    } catch (SQLException ex) {
//                        ex.printStackTrace();
//                    }
//                }
//                e.printStackTrace();
//                showErrorAlert(e.getMessage());
//            } finally {
//
//                if (conn != null) {
//                    try {
//                        conn.setAutoCommit(true);
//                        conn.close();
//                    } catch (SQLException e) {
//                        e.printStackTrace();
//                    }
//                }
//            }
//        } else {
//            showErrorAlert("Please select a request to accept.");
//        }
//    }
    @FXML
    private void logout(ActionEvent event){
        Plogout(event);
    }



}

