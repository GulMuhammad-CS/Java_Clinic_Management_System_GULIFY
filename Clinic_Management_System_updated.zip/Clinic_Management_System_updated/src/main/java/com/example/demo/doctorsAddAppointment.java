package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.sql.*;
import java.time.LocalDate;

import static com.example.demo.changepage.changePage;
import static com.example.demo.doctors.getCurrentDoctorID;

public class doctorsAddAppointment {
    String url = "jdbc:sqlite:Clinic_database.db";
    public void showErrorAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText("Something went wrong!");

        alert.setContentText(message);
        alert.showAndWait();
    }
    public void showSuccessAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Success");
        alert.setHeaderText("Appointment booking successful!");
        alert.setContentText(message);
        alert.showAndWait();
    }
    @FXML
    private TextField patientIDfield;
    @FXML
    private DatePicker appointmentDateField;
    @FXML
    private ChoiceBox<String> appointmentTimeField;
    String appointmentStatus="upcoming";
    int doctorid=getCurrentDoctorID();
    @FXML
    public void initialize(){
        try{
            ObservableList<String> timeList= FXCollections.observableArrayList();
            timeList.add("9:00");
            timeList.add("10:00");
            timeList.add("11:00");
            timeList.add("12:00");
            timeList.add("13:00");
            timeList.add("14:00");
            timeList.add("15:00");
            timeList.add("16:00");
            timeList.add("17:00");
            timeList.add("18:00");
            appointmentTimeField.setItems(timeList);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
            showErrorAlert(e.getMessage());
            return;
        }
    }
    @FXML
    private void handleSubmit(ActionEvent event) {
        if(patientIDfield.getText()==null || patientIDfield.getText().trim().isEmpty()){
            showErrorAlert("Patient ID is empty!");
            return;
        }
        int patientID;
        try{
            patientID=Integer.parseInt(patientIDfield.getText());
        }
        catch(NumberFormatException e){
            showErrorAlert("Patient ID is invalid! Please enter a valid Integer!");
            return;
        }
        if(appointmentDateField.getValue()==null){
            showErrorAlert("Appointment Date is empty!");
            return;
        }
        LocalDate appointmentDate = appointmentDateField.getValue();
        if(appointmentTimeField.getValue()==null){
            showErrorAlert("Please select an appointment time!");
            return;
        }
        String appointmentTime = appointmentTimeField.getValue().toString();
        boolean patientExists = false;
        try(Connection conn=DriverManager.getConnection(url);
            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT PatientID FROM Patients WHERE DoctorID='"+getCurrentDoctorID()+"';");){
            while(rs.next()){
                if(patientID==rs.getInt("PatientID")){
                    patientExists = true;
                    break;
                }
            }
        }
        catch(Exception e){
            e.printStackTrace();
            showErrorAlert(e.getMessage());
            return;
        }
        if(!patientExists){
            showErrorAlert("Patient does not exist!");
            return;

        }
        if(appointmentDate.isBefore(LocalDate.now())){
            showErrorAlert("Appointment Date is older than current date! Please choose a date after today.");
            return;
        }
        //checks to make sure chosen time slot isn't already booked or has been requested by another patient
        try (Connection conn = DriverManager.getConnection(url);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT AppointmentDate, AppointmentTime FROM Appointments WHERE (" +
                     "AppointmentStatus='upcoming' OR AppointmentStatus='requested') AND DoctorID='"+getCurrentDoctorID()+"';")) {

            while(rs.next()) {
                Date sqlDate = rs.getDate("AppointmentDate");
                LocalDate localDate = null;
                if (sqlDate != null) {
                    localDate = sqlDate.toLocalDate();
                }
                if(localDate.equals(appointmentDate) && appointmentTime.equals(rs.getString("AppointmentTime"))) {
                showErrorAlert("This time slot has already been booked! Please select another date or time");
                    return;
                }
            }
        } catch (Exception e) {
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;
        }
        try (Connection conn = DriverManager.getConnection(url);){
            String sql = "INSERT INTO Appointments (DoctorID, PatientID, AppointmentDate, AppointmentTime, AppointmentStatus) " +
                    "VALUES (?, ?, ?, ?, ?)";

            // Create a PreparedStatement
            PreparedStatement pstmt = conn.prepareStatement(sql);

            // Set each parameter with the appropriate data type
            pstmt.setInt(1, getCurrentDoctorID());
            pstmt.setInt(2, patientID);
            pstmt.setDate(3, java.sql.Date.valueOf(appointmentDate));  // Should be hashed in production
            pstmt.setString(4, appointmentTime);
            pstmt.setString(5, appointmentStatus);

            // Execute the statement
            pstmt.executeUpdate();
            patientIDfield.clear();
            appointmentDateField.setValue(null);
            appointmentTimeField.setValue(null);
            showSuccessAlert("Appointment for "+appointmentDate+" at "+appointmentTime+" has successfully been registered!");
        } catch (Exception e) {
            showErrorAlert("Database error: " + e.getMessage());
            e.printStackTrace();
            return;

        }
        changePage(event, "doctorProfilepage.fxml", true);
    }
    @FXML
    private Button cancelbutton;
    @FXML
    private void cancel(ActionEvent event) {
        changePage(event, "doctorProfilepage.fxml", true);
    }
}
