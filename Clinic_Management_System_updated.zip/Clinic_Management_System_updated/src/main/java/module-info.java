module com.example.demo {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;
    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires net.synedra.validatorfx;
    requires org.kordamp.bootstrapfx.core;
    requires eu.hansolo.tilesfx;
    requires java.sql;
    requires javafx.graphics;
    requires junit;
//    requires org.junit.jupiter.api;
//    requires org.mockito;
    requires jakarta.mail;
    opens com.example.demo to javafx.fxml, javafx.base;
    exports com.example.demo;
}